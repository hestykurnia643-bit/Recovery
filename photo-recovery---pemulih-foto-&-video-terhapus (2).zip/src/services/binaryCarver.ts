import { MediaFormat, QualityEstimate, RecoveryTier } from '../types';
import { testImageDecoder, testVideoDecoder } from './decoderValidator';
import {
  getRealPlayableVideoBlob,
  getRealPlayableVideoArrayBuffer,
  createVibrantTestPhotoBuffer
} from './realMediaSamples';

export interface CarveResult {
  format: MediaFormat;
  type: 'image' | 'video';
  tier: RecoveryTier;
  quality: QualityEstimate;
  integrityScore: number;
  isCorrupted: boolean;
  canPreview: boolean;
  canRecover: boolean;
  resolution?: string;
  duration?: string;
  codec?: string;
  magicHeader: string;
  blob?: Blob;
  sizeBytes: number;
  unrecoverableReason?: string;
  decoderTested: boolean;
  decoderMessage?: string;
}

/**
 * Validasi biner mendalam menggunakan ImageDecoder & Video Demuxer
 * Membedakan secara nyata:
 * - FULL_VALID (Data asli valid dan terbukti dapat didekode)
 * - PARTIAL (Sebagian data tersedia)
 * - HEADER_ONLY/CORRUPT (Header ada tetapi payload tidak dapat didekode / blank)
 * - THUMBNAIL_ONLY (Hanya thumbnail cache resolusi rendah)
 * - METADATA_ONLY (Hanya baris metadata tanpa blok fisik)
 * - UNRECOVERABLE (Sektor rusak total)
 */
export async function analyzeBinaryHeader(
  buffer: ArrayBuffer,
  fileName: string,
  filePath: string
): Promise<CarveResult> {
  const bytes = new Uint8Array(buffer);
  const lowerPath = filePath.toLowerCase();
  const lowerName = fileName.toLowerCase();

  // 1. Kasus: File 0 Byte / Hanya record MediaStore
  if (bytes.length === 0) {
    return {
      format: 'JPG',
      type: 'image',
      tier: 'METADATA_ONLY',
      quality: 'Hanya Metadata (Data Fisik Kosong)',
      integrityScore: 0,
      isCorrupted: true,
      canPreview: false,
      canRecover: false,
      magicHeader: 'KOSONG (0 Bytes)',
      sizeBytes: 0,
      unrecoverableReason:
        'Sektor fisik telah di-zero out oleh TRIM flash storage saat trash dikosongkan. Hanya catatan nama & tanggal yang tersisa di MediaStore SQLite.',
      decoderTested: true,
      decoderMessage: 'Ukuran file 0 byte: Tidak ada byte fisik untuk didekode.'
    };
  }

  const isFromThumbnailDir =
    lowerPath.includes('.thumbnails') ||
    lowerName.startsWith('.thumbdata') ||
    lowerName.includes('thumb');

  // ==================== JPEG ====================
  if (bytes.length >= 3 && bytes[0] === 0xFF && bytes[1] === 0xD8 && bytes[2] === 0xFF) {
    let hasEoi = false;
    const scanLimit = Math.max(0, bytes.length - 256);
    for (let i = bytes.length - 2; i >= scanLimit; i--) {
      if (bytes[i] === 0xFF && bytes[i + 1] === 0xD9) {
        hasEoi = true;
        break;
      }
    }

    const blob = new Blob([buffer], { type: 'image/jpeg' });
    // JALANKAN TEST DECODER NYATA
    const decodeResult = await testImageDecoder(blob);

    if (!decodeResult.isValid) {
      // Header JPEG valid, tetapi decoder gagal merender piksel!
      return {
        format: 'JPG',
        type: 'image',
        tier: 'HEADER_ONLY/CORRUPT',
        quality: 'Hanya Header / Data Korup',
        integrityScore: 25,
        isCorrupted: true,
        canPreview: false,
        canRecover: false,
        magicHeader: 'FF D8 FF (Payload Rusak / Blank)',
        blob,
        sizeBytes: bytes.length,
        unrecoverableReason: decodeResult.errorMessage || 'Header JPEG ada tetapi payload tidak berisi data piksel valid.',
        decoderTested: true,
        decoderMessage: decodeResult.errorMessage
      };
    }

    const resolution = `${decodeResult.width} x ${decodeResult.height}`;
    const isSmallThumb = (decodeResult.width <= 400 && decodeResult.height <= 400) || isFromThumbnailDir;

    if (!hasEoi) {
      return {
        format: 'JPG',
        type: 'image',
        tier: 'PARTIAL',
        quality: 'Fragment Rusak / Sebagian',
        integrityScore: 50,
        isCorrupted: true,
        canPreview: true,
        canRecover: true,
        resolution,
        magicHeader: 'FF D8 FF (EOI Hilang / Truncated)',
        blob,
        sizeBytes: bytes.length,
        decoderTested: true,
        decoderMessage: 'Piksel terbaca sebagian hingga batas fragmen terputus.'
      };
    }

    if (isSmallThumb) {
      return {
        format: 'JPG',
        type: 'image',
        tier: 'THUMBNAIL_ONLY',
        quality: 'Thumbnail Saja (Resolusi Rendah)',
        integrityScore: 88,
        isCorrupted: false,
        canPreview: true,
        canRecover: true,
        resolution,
        magicHeader: 'FF D8 FF (Thumbnail Cache)',
        blob,
        sizeBytes: bytes.length,
        decoderTested: true,
        decoderMessage: `Decoder sukses: Thumbnail terverifikasi (${resolution} px).`
      };
    }

    // LULUS SEMUA VALIDASI: FULL_VALID
    return {
      format: 'JPG',
      type: 'image',
      tier: 'FULL_VALID',
      quality: 'Utuh (Data Asli Valid & Terdekode)',
      integrityScore: 100,
      isCorrupted: false,
      canPreview: true,
      canRecover: true,
      resolution,
      magicHeader: 'FF D8 FF E1 (JPEG Exif Intact)',
      blob,
      sizeBytes: bytes.length,
      decoderTested: true,
      decoderMessage: `Decoder sukses: Gambar asli terverifikasi (${resolution} px, variance ${decodeResult.pixelVariance}%).`
    };
  }

  // ==================== PNG ====================
  if (
    bytes.length >= 8 &&
    bytes[0] === 0x89 &&
    bytes[1] === 0x50 &&
    bytes[2] === 0x4E &&
    bytes[3] === 0x47
  ) {
    const blob = new Blob([buffer], { type: 'image/png' });
    const decodeResult = await testImageDecoder(blob);

    if (!decodeResult.isValid) {
      return {
        format: 'PNG',
        type: 'image',
        tier: 'HEADER_ONLY/CORRUPT',
        quality: 'Hanya Header / Data Korup',
        integrityScore: 25,
        isCorrupted: true,
        canPreview: false,
        canRecover: false,
        magicHeader: '89 50 4E 47 (IHDR Rusak / Blank)',
        blob,
        sizeBytes: bytes.length,
        unrecoverableReason: decodeResult.errorMessage || 'Payload PNG korup.',
        decoderTested: true,
        decoderMessage: decodeResult.errorMessage
      };
    }

    const resolution = `${decodeResult.width} x ${decodeResult.height}`;
    const isSmallThumb = (decodeResult.width <= 320 && decodeResult.height <= 320) || isFromThumbnailDir;

    return {
      format: 'PNG',
      type: 'image',
      tier: isSmallThumb ? 'THUMBNAIL_ONLY' : 'FULL_VALID',
      quality: isSmallThumb ? 'Thumbnail Saja (Resolusi Rendah)' : 'Utuh (Data Asli Valid & Terdekode)',
      integrityScore: isSmallThumb ? 88 : 100,
      isCorrupted: false,
      canPreview: true,
      canRecover: true,
      resolution,
      magicHeader: '89 50 4E 47 (PNG Valid)',
      blob,
      sizeBytes: bytes.length,
      decoderTested: true,
      decoderMessage: `Decoder sukses: PNG terverifikasi (${resolution} px).`
    };
  }

  // ==================== MP4 / MOV (Video) ====================
  if (bytes.length >= 12 && bytes[4] === 0x66 && bytes[5] === 0x74 && bytes[6] === 0x79 && bytes[7] === 0x70) {
    const brand = String.fromCharCode(bytes[8], bytes[9], bytes[10], bytes[11]);
    const isMov = brand.toLowerCase().includes('qt');
    const format: MediaFormat = isMov ? 'MOV' : 'MP4';
    const blob = new Blob([buffer], { type: isMov ? 'video/quicktime' : 'video/mp4' });

    // JALANKAN TEST DECODER VIDEO NYATA (Demuxer & Frame Verification)
    const videoDiagnosis = await testVideoDecoder(blob);

    if (!videoDiagnosis.isValid || !videoDiagnosis.hasDecodeableFrames) {
      return {
        format,
        type: 'video',
        tier: 'HEADER_ONLY/CORRUPT',
        quality: 'Hanya Header / Data Korup',
        integrityScore: 30,
        isCorrupted: true,
        canPreview: false,
        canRecover: false,
        magicHeader: `ftyp ${brand} (Box moov/mdat rusak)`,
        blob,
        sizeBytes: bytes.length,
        unrecoverableReason: videoDiagnosis.errorMessage || 'Video container tidak memiliki keyframe H.264 yang dapat didekode.',
        decoderTested: true,
        decoderMessage: videoDiagnosis.errorMessage
      };
    }

    const durationStr = `00:0${Math.max(1, Math.round(videoDiagnosis.duration))}`;
    const resolution = `${videoDiagnosis.width} x ${videoDiagnosis.height}`;

    return {
      format,
      type: 'video',
      tier: 'FULL_VALID',
      quality: 'Utuh (Data Asli Valid & Terdekode)',
      integrityScore: 100,
      isCorrupted: false,
      canPreview: true,
      canRecover: true,
      resolution,
      duration: durationStr,
      codec: videoDiagnosis.codec || 'H.264 / AVC',
      magicHeader: `ftyp ${brand} (Valid Stream)`,
      blob,
      sizeBytes: bytes.length,
      decoderTested: true,
      decoderMessage: `Media3/VideoDecoder sukses: Track video terverifikasi (${resolution}, durasi ${durationStr}).`
    };
  }

  // ==================== UNRECOVERABLE ====================
  return {
    format: 'JPG',
    type: 'image',
    tier: 'UNRECOVERABLE',
    quality: 'Tidak Dapat Dipulihkan',
    integrityScore: 10,
    isCorrupted: true,
    canPreview: false,
    canRecover: false,
    magicHeader: 'Byte Acak / Corrupted Sector',
    sizeBytes: bytes.length,
    unrecoverableReason: 'Blok data rusak total atau tertimpa data baru sehingga signature tidak dikenali.',
    decoderTested: true,
    decoderMessage: 'Format biner tidak dikenali.'
  };
}

/**
 * Carving JPEG dari container biner .thumbdata
 * Menghasilkan item dengan tier eksplisit: THUMBNAIL_ONLY
 */
export async function carveJpegFromThumbdata(buffer: ArrayBuffer, baseFileName: string): Promise<CarveResult[]> {
  const bytes = new Uint8Array(buffer);
  const carvedList: CarveResult[] = [];
  const minJpegSize = 2048;
  let offset = 0;

  while (offset < bytes.length - minJpegSize && carvedList.length < 25) {
    if (bytes[offset] === 0xFF && bytes[offset + 1] === 0xD8 && bytes[offset + 2] === 0xFF) {
      const startIndex = offset;
      let endIndex = -1;

      const maxSearch = Math.min(bytes.length - 2, startIndex + 5 * 1024 * 1024);
      for (let j = startIndex + 128; j < maxSearch; j++) {
        if (bytes[j] === 0xFF && bytes[j + 1] === 0xD9) {
          endIndex = j + 2;
          break;
        }
      }

      if (endIndex > startIndex && endIndex - startIndex >= minJpegSize) {
        const jpegBytes = bytes.slice(startIndex, endIndex);
        const blob = new Blob([jpegBytes], { type: 'image/jpeg' });
        const decodeResult = await testImageDecoder(blob);

        if (decodeResult.isValid) {
          carvedList.push({
            format: 'JPG',
            type: 'image',
            tier: 'THUMBNAIL_ONLY',
            quality: 'Thumbnail Saja (Resolusi Rendah)',
            integrityScore: 88,
            isCorrupted: false,
            canPreview: true,
            canRecover: true,
            resolution: `${decodeResult.width} x ${decodeResult.height} (Cache)`,
            magicHeader: 'FF D8 FF (Carved .thumbdata)',
            blob,
            sizeBytes: jpegBytes.length,
            decoderTested: true,
            decoderMessage: `Decoder sukses: Thumbnail cache terverifikasi (${decodeResult.width}x${decodeResult.height}).`
          });
        }
        offset = endIndex;
        continue;
      }
    }
    offset += 512;
  }

  return carvedList;
}

/**
 * Membuat data partisi Android nyata dengan uji decoder lengkap
 */
export async function createComprehensiveAndroidTestData(): Promise<{
  activeGalleryFiles: { name: string; path: string; buffer: ArrayBuffer }[];
  storageCandidates: {
    name: string;
    path: string;
    buffer: ArrayBuffer;
    prebuiltBlob?: Blob;
    tier: RecoveryTier;
    quality: QualityEstimate;
    isCorrupted: boolean;
    canPreview: boolean;
    canRecover: boolean;
    format: MediaFormat;
    type: 'image' | 'video';
    resolution?: string;
    duration?: string;
    unrecoverableReason?: string;
    decoderTested: boolean;
    decoderMessage: string;
  }[];
}> {
  // 1. Foto Aktif di Galeri (WAJIB DIFILTER KELUAR)
  const activeGalleryFiles = [
    {
      name: 'IMG_20240401_AKTIF_GALERI.JPG',
      path: 'DCIM/Camera/IMG_20240401_AKTIF_GALERI.JPG',
      buffer: createVibrantTestPhotoBuffer(1280, 720, 'FOTO AKTIF DI GALERI', 'DOKUMEN')
    }
  ];

  // 2. Video FULL_VALID yang nyata (H.264 MP4 asli) & terbukti dapat diputar
  const verifiedVideoBlob = getRealPlayableVideoBlob();
  const verifiedVideoBuffer = getRealPlayableVideoArrayBuffer();

  // 3. Foto FULL_VALID yang terbukti memiliki piksel hidup
  const verifiedPhotoBuffer = createVibrantTestPhotoBuffer(1280, 720, 'FOTO ASLI PENUH: Sunset Pantai', 'PANTAI');

  // 4. File Header Saja / Korup (Header JPEG ada tapi payload blank / corrupt)
  const headerOnlyBuffer = new Uint8Array(2048);
  headerOnlyBuffer[0] = 0xFF;
  headerOnlyBuffer[1] = 0xD8;
  headerOnlyBuffer[2] = 0xFF;
  headerOnlyBuffer[3] = 0xE0; // JPEG SOI + APP0
  // Sisa byte dibiarkan nol (tidak ada SOF, tidak ada scanline, gagal decode)

  const storageCandidates = [
    // [FULL_VALID 1] Foto asli penuh yang terbukti terdekode
    {
      name: '.trashed-1714562700-SunsetPantai.jpg',
      path: 'Pictures/.trashed-1714562700-SunsetPantai.jpg',
      buffer: verifiedPhotoBuffer,
      prebuiltBlob: new Blob([verifiedPhotoBuffer], { type: 'image/jpeg' }),
      tier: 'FULL_VALID' as RecoveryTier,
      quality: 'Utuh (Data Asli Valid & Terdekode)' as QualityEstimate,
      isCorrupted: false,
      canPreview: true,
      canRecover: true,
      format: 'JPG' as MediaFormat,
      type: 'image' as const,
      resolution: '1280 x 720',
      decoderTested: true,
      decoderMessage: 'ImageDecoder sukses: 100% data raster piksel valid & terdekode.'
    },
    // [FULL_VALID 2] Video asli penuh yang terbukti dapat diputar
    {
      name: 'VID_20240501_SENJA_TRASHED.MP4',
      path: 'DCIM/Camera/.trashed-171829012.mp4',
      buffer: verifiedVideoBuffer,
      prebuiltBlob: verifiedVideoBlob,
      tier: 'FULL_VALID' as RecoveryTier,
      quality: 'Utuh (Data Asli Valid & Terdekode)' as QualityEstimate,
      isCorrupted: false,
      canPreview: true,
      canRecover: true,
      format: 'MP4' as MediaFormat,
      type: 'video' as const,
      resolution: '426 x 240',
      duration: '00:02',
      decoderTested: true,
      decoderMessage: 'Media3 ExoPlayer / H.264 Demuxer sukses: Track video terverifikasi (426x240, AVC1 Baseline).'
    },
    // [THUMBNAIL_ONLY] Ekstraksi cache .thumbdata
    {
      name: 'THUMB_CACHE_DCIM_001.JPG',
      path: 'DCIM/.thumbnails/.thumbdata4--1967290299',
      buffer: createVibrantTestPhotoBuffer(256, 192, 'THUMBNAIL CACHE', 'THUMBNAIL'),
      prebuiltBlob: new Blob([createVibrantTestPhotoBuffer(256, 192, 'THUMBNAIL CACHE', 'THUMBNAIL')], { type: 'image/jpeg' }),
      tier: 'THUMBNAIL_ONLY' as RecoveryTier,
      quality: 'Thumbnail Saja (Resolusi Rendah)' as QualityEstimate,
      isCorrupted: false,
      canPreview: true,
      canRecover: true,
      format: 'JPG' as MediaFormat,
      type: 'image' as const,
      resolution: '256 x 192 (Cache)',
      decoderTested: true,
      decoderMessage: 'ImageDecoder sukses: Cache thumbnail sistem terverifikasi.'
    },
    // [HEADER_ONLY/CORRUPT] Signature ada tetapi payload gagal didekode
    {
      name: 'IMG_HEADER_ONLY_CORRUPTED.JPG',
      path: 'storage/emulated/0/LOST.DIR/Cluster_8492',
      buffer: headerOnlyBuffer.buffer,
      prebuiltBlob: new Blob([headerOnlyBuffer], { type: 'image/jpeg' }),
      tier: 'HEADER_ONLY/CORRUPT' as RecoveryTier,
      quality: 'Hanya Header / Data Korup' as QualityEstimate,
      isCorrupted: true,
      canPreview: false,
      canRecover: false,
      format: 'JPG' as MediaFormat,
      type: 'image' as const,
      unrecoverableReason: 'ImageDecoder gagal: Signature JPEG valid (FF D8 FF) tetapi payload tidak berisi data piksel yang dapat didekode.',
      decoderTested: true,
      decoderMessage: 'ImageDecoder Error: Payload scanline hancur / tidak ada data piksel.'
    },
    // [PARTIAL] Fragment foto terpotong
    {
      name: 'LOST_DIR_FRAGMENT_04918.JPG',
      path: 'LOST.DIR/LOST_DIR_FRAGMENT_04918.JPG',
      buffer: verifiedPhotoBuffer.slice(0, 18000),
      prebuiltBlob: new Blob([verifiedPhotoBuffer.slice(0, 18000)], { type: 'image/jpeg' }),
      tier: 'PARTIAL' as RecoveryTier,
      quality: 'Fragment Rusak / Sebagian' as QualityEstimate,
      isCorrupted: true,
      canPreview: true,
      canRecover: true,
      format: 'JPG' as MediaFormat,
      type: 'image' as const,
      resolution: '1280 x 720 (Terpotong)',
      decoderTested: true,
      decoderMessage: 'ImageDecoder sebagian: Terpotong di tengah stream (EOI hilang).'
    },
    // [METADATA_ONLY] Record MediaStore tanpa data fisik
    {
      name: 'IMG_20240315_METADATA_RECORD.JPG',
      path: 'MediaStore.Images / Row ID: 94812',
      buffer: new ArrayBuffer(0),
      tier: 'METADATA_ONLY' as RecoveryTier,
      quality: 'Hanya Metadata (Data Fisik Kosong)' as QualityEstimate,
      isCorrupted: true,
      canPreview: false,
      canRecover: false,
      format: 'JPG' as MediaFormat,
      type: 'image' as const,
      unrecoverableReason: 'Sektor fisik telah di-zero out oleh TRIM flash storage setelah trash dikosongkan. Hanya catatan nama & tanggal yang tersisa di MediaStore SQLite.',
      decoderTested: true,
      decoderMessage: 'Ukuran file 0 byte: Data fisik tidak ada.'
    }
  ];

  return { activeGalleryFiles, storageCandidates };
}
