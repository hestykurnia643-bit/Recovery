/**
 * Real Media Samples & Forensic Utilities
 * Menyediakan data biner valid untuk foto & video terdekode nyata (H.264 MP4 & JPEG)
 */

export const REAL_MP4_BASE64 = 'AAAAIGZ0eXBpc29tAAACAGlzb21pc28yYXZjMW1wNDEAAASTbW9vdgAAAGxtdmhkAAAAAAAAAAAAAAAAAAAD6AAAB9AAAQAAAQAAAAAAAAAAAAAAAAEAAAAAAAAAAAAAAAAAAAABAAAAAAAAAAAAAAAAAABAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgAAA710cmFrAAAAXHRraGQAAAADAAAAAAAAAAAAAAABAAAAAAAAB9AAAAAAAAAAAAAAAAAAAAAAAAEAAAAAAAAAAAAAAAAAAAABAAAAAAAAAAAAAAAAAABAAAAAAaoAAADwAAAAAAAkZWR0cwAAABxlbHN0AAAAAAAAAAEAAAfQAAAIAAABAAAAAAM1bWRpYQAAACBtZGhkAAAAAAAAAAAAAAAAAAA8AAAAeABVxAAAAAAALWhkbHIAAAAAAAAAAHZpZGUAAAAAAAAAAAAAAABWaWRlb0hhbmRsZXIAAAAC4G1pbmYAAAAUdm1oZAAAAAEAAAAAAAAAAAAAACRkaW5mAAAAHGRyZWYAAAAAAAAAAQAAAAx1cmwgAAAAAQAAAqBzdGJsAAAAwHN0c2QAAAAAAAAAAQAAALBhdmMxAAAAAAAAAAEAAAAAAAAAAAAAAAAAAAAAAaoA8ABIAAAASAAAAAAAAAABAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAGP//AAAANmF2Y0MBZAAV/+EAGmdkABWs2UGx/k8BEAAAAwAQAAADAeDxYtlgAQAFaO+GcsD9+PgAAAAAEHBhc3AAAAABAAAAAQAAABRidHJ0AAAAAAAAeFQAAHhUAAAAGHN0dHMAAAAAAAAAAQAAAB4AAAQAAAAAFHN0c3MAAAAAAAAAAQAAAAEAAADwY3R0cwAAAAAAAAAcAAAAAQAACAAAAAABAAAQAAAAAAIAAAQAAAAAAQAAFAAAAAABAAAIAAAAAAEAAAAAAAAAAQAABAAAAAABAAAUAAAAAAEAAAgAAAAAAQAAAAAAAAABAAAEAAAAAAEAAAwAAAAAAQAABAAAAAABAAAIAAAAAAEAAAwAAAAAAQAABAAAAAABAAAUAAAAAAEAAAgAAAAAAQAAAAAAAAABAAAEAAAAAAEAABAAAAAAAgAABAAAAAABAAAUAAAAAAEAAAgAAAAAAQAAAAAAAAABAAAEAAAAAAEAAAwAAAAAAQAABAAAAAAcc3RzYwAAAAAAAAABAAAAAQAAAB4AAAABAAAAjHN0c3oAAAAAAAAAAAAAAB4AAAwNAAABvAAAABcAAAAXAAAB9AAAACoAAAAUAAAADgAAAdgAAAAvAAAAEwAAABcAAAFdAAAAEQAAASQAAAHVAAAAFwAAAfEAAABOAAAAGwAAAA4AAAFxAAAAHAAAABAAAAGlAAAAOwAAABEAAAAZAAABEgAAAA4AAAAUc3RjbwAAAAAAAAABAAAEwwAAAGJ1ZHRhAAAAWm1ldGEAAAAAAAAAIWhkbHIAAAAAAAAAAG1kaXJhcHBsAAAAAAAAAAAAAAAALWlsc3QAAAAlqXRvbwAAAB1kYXRhAAAAAQAAAABMYXZmNTguNzYuMTAwAAAACGZyZWUAAB4dbWRhdAAAAq0GBf//qdxF6b3m2Ui3lizYINkj7u94MjY0IC0gY29yZSAxNjMgcjMwNjAgNWRiNmFhNiAtIEguMjY0L01QRUctNCBBVkMgY29kZWMgLSBDb3B5bGVmdCAyMDAzLTIwMjEgLSBodHRwOi8vd3d3LnZpZGVvbGFuLm9yZy94MjY0Lmh0bWwgLSBvcHRpb25zOiBjYWJhYz0xIHJlZj0xIGRlYmxvY2s9MTowOjAgYW5hbHlzZT0weDM6MHgxMTMgbWU9aGV4IHN1Ym1lPTIgcHN5PTEgcHN5X3JkPTEuMDA6MC4wMCBtaXhlZF9yZWY9MCBtZV9yYW5nZT0xNiBjaHJvbWFfbWU9MSB0cmVsbGlzPTAgOHg4ZGN0PTEgY3FtPTAgZGVhZHpvbmU9MjEsMTEgZmFzdF9wc2tpcD0xIGNocm9tYV9xcF9vZmZzZXQ9MCB0aHJlYWRzPTMgbG9va2FoZWFkX3RocmVhZHM9MSBzbGljZWRfdGhyZWFkcz0wIG5yPTAgZGVjaW1hdGU9MSBpbnRlcmxhY2VkPTAgYmx1cmF5X2NvbXBhdD0wIGNvbnN0cmFpbmVkX2ludHJhPTAgYmZyYW1lcz0zIGJfcHlyYW1pZD0yIGJfYWRhcHQ9MSBiX2JpYXM9MCBkaXJlY3Q9MSB3ZWlnaHRiPTEgb3Blbl9nb3A9MCB3ZWlnaHRwPTEga2V5aW50PTI1MCBrZXlpbnRfbWluPTE1IHNjZW5lY3V0PTQwIGludHJhX3JlZnJlc2g9MCByY19sb29rYWhlYWQ9MTAgcmM9Y3JmIG1idHJlZT0xIGNyZj0zMi4wIHFjb21wPTAuNjAgcXBtaW49MCBxcG1heD02OSBxcHN0ZXA9NCBpcF9yYXRpbz0xLjQwIGFxPTE6MS4wMACAAAAJWGWIhAAz/5QBsXavmV8B/7xaZuPQat40BHtsIihGNZt6bGiu8zOeVYMUUPQcZUn3CBJHNnWeENm4X0Brgu+zJKfaoOZqRQYO3UQZ5+VhOVJtEDqTnh0yiaXRfL/Avjp1yVe72GmzjO32wwpqkmczX3Xs61lzYrWya8Vk5a5C/G0MtpBLP0I+oQTQ0BiA1xK8uhqVpXQm1kk1Gv+hvFgdO41tunIeZaHYTQB3tq+PBjme49an4acwVW1iZMTjrVZhfYzcQWM26wTEkIIwiHNNwXV5/u//g6gciLPnuiv/sID6nEWIRb3I8x0rGzgdMs+vePIKnwIYCo2zMfjLp1bhgDBMzB2Efp5XG8R4BawDO8BbYaLiLTCe3aBSLhA/a3MUI7iFRBHngNDaB1y1CRd+4g+zahL/cNFGRwTM3lmyPFQmVIrtS6D0+cqvRuSAg/HIcwtIYZ6Qlq3tRr4xN7nQrQXR0T6kVGoEbpf0upsvaGhi5TuapWQDeGYhAW8R3nVcbXUiH1URfyeXh1xqHzqBWRVWoEPhDvZWHKDjmfaWk8hwD0rHiiTG2st9NzQuByk7NEt7leUnVkH+hX8txiBVwAGTr5IoO8SqWa+3w6AG+90Xwc7pgmUDE+I9zHz2GYNAC+Qmat4DYT4k4djNUjV7nzjwznl6cw/p3sLYycdPeIHq0td/DU4jeLBrNY2NswqKWMG0Mz1rwqrYQQNmcCxfwVCzBB0LHbO/v2T5gmePhhS3J38TvyiEloVfcRSacdnfxpSkS79hePh5oPZe2g5lo5FhLaWE4Hhdn+hDAW1M/yGZDnQgIoZjygLPlpHf57YyX9c/ggw2MXv6Vz8fk7hUxP2V9R4I0cl2fYJFXvbEOAoUZEAhj/MQfcK/PTjy55m3KXmLusisKhSQFkCHIdKbrtQrOjW+LcnyAolb452eu+Nj2iReAEMVXKoxsXjEB5vsw7CGcic5wnuJ5paJOuK5mzK3YJ7S3SjCL2Il1iRBkX2Ol1T1zYJzUbGqI4xppboPazi/NrAANENmPDjMZfiI+hu8Ee7R2vTUP/+Ahbp4hkRKBujgRWEXbT0wlUXEhufhMSa7EPSg/lt5WkMIkDnbOoW14Q77iM9aokD6Vi4orInE1FohxMQYSkBUSaaYjwpcmUh7tYC7NvGHnlrvWeRAEViHJ1vDol8uBH1M2inYmb1tOmCA2KUsYv5LlHW4xSfZP08kOpItACQrGcZ7UG03WE2nJitJavqawEJViK4V3x2RLXuGD0yMPemz6fS76oT+SqNRY8A6Kuwi2p7LZ+zx7rpbeNT1VCmf/gRu+lzA1txlU4L6lrmGRHixVCB+tiCr2JJViVeBU3f8nhC2oP75cd+m0XUhgLAIbW1mm0zPhjpm7aHEoZVG7byO/fpGYldupBnql5ptDdMXz6TX91kOoldYvhsA58D9eDEjtW3I0mFwdyf6OubgEzNl+lyI8dmlD4Lpk4BsUntxN2s/kcaW5ttw6kb0tKiS5oNinRVx/QXCov+jOxQnb5ZcN8B+t+a+nEIambDseYbNk42m5nezvRqAszDBktuJZMkEW94l0UGMOsdPC5ZV0hbK+6FPG6DtdMZMcCuhhwh51fltX5wu+uirRBak7JRqKCxCiTPYBBqpeYJLqBg2wX/XJlKF/NiRwvUqMlSHDM4VmRry701SECMDjoW6vJvFdG8NB7FOlTbiytBD0RhkSH4WNPJnGWJoDFsZbQahGx9nHzrV6ky0CHxWuRx2RKshVpkbvTd4wHpA9A9fRq/2G+nc+HcWS9F811mlz7OaDUmujJC150NepzzppIOU373QP3IwnW5NOfz7t5D7Sw+AC3NQzhQiQwZ9tOEAj8uQf/AM8kfdAn6o67bwVT/QRU3mG6k7GEo0+vv2gqWjyOm5kf1duhr9Z3wxKIpT6oMvnuOlVXzcgNnwY4hXHzBXjprh7TN1Nbys5wGcbGONJrBK6gC02GlOX1KwqsRSmvD5cE7+uORN2PMpcS4iaijgttZRJ26Ly3q8GpNbb8QMnslWae6WHhhS/RdLsF9qklf6Q9PVATgQ80UuvyTc2jx60GJ61CNw5v2VaK1CISKAFU7fN1v0MgdwuCBitE73V2CvGd3zQcB5NExHrLmust8QPCFcCdKXEk02FAC9GW8xG9VjCyzW8vBUMV/JCybKK2vVcmnoc5KvXLnMJN+eL5262lpRO1Rzih3DkL35940x41XLYCy/stKbd0o+zcJWl0u9us3bPJtSDKDrCjuM9P0AWwXINJGF6HYs0aZL4intoPjTNZiCbFJtwC2xxsgx7dpU+anQWYgYMqr0xW6kg30LF4Ly0yjiHeOGTj8S+00lKgv6Cbq+byKHSl0lgTc9XQ6Yio1JmABGHnE9CRttiiPSb5BzUyb/fX/zeL+iHdnFnzA1bTEaK6d/WbjsOevOjUvFUji+3zUjwpyg9ASh7wPwIKB8ZrKRu9LL1cbRCXvO6IrieXN3NyfLsVEJwS+gftanfJFpUbue9srT/xYm6dCs1+quqFlbs/klxLgltgmss/1DN01ky7E2muX1S8zAGHukfGpYfJJBn9mAFidAdaNhPL0oXUPKkGeAACxi0gCBV50m3Xgqc4CWBNSwBi/B5iRs+2JWcWBWkMBF9FhdcNIrSRLqKi98c6sVAERl56jZJIEv/8w/by5sJvKnrbRUV5jZmX4yVqHwt+yh1Liu2o32+JvuudBPQSG0XjmydRR7P5cZXXEGgtrB4GY4uDi1PjyBFttfLIBegjcchFl8EApfJvmCyGIuAp0+WosFVF67nMSdTVdPsR9WH0fC/51xRVUYi+j5RsQX1N6ftCz2g9MR5H2PhdsZRRoqDI61T/5UMhDslWVQBt2kPWR46CBF9zos4ES+sLG2Uryz/CIzfiVka3EMIwABWyWmY/Z5WEECpePgDEFVCXhMY6+OmvV0yMSHRycYatOsEieZY7TGDKirCk5vUNxc8XeD0JV8XWeG8QV+9H2XL6ojR5btB99k/yNPAPPTjknylEnnuH7zRhay01FKcdFJF6DDxywizub196H+sZ/KB+fYJuSBewUnIpYFg/H6ZGyvNEszUbvuAqDpbkHlhC27uutx4Q/RarJQvIBTzVXvzjYIMsFKg432zdwOVKNK71CV5ocwzQIuyefzBqd7xsJ9UECefiqxZEIUuhwAnX8AAAG4QZojGIZ/5EAFs8K9JASkEKJXa98lfAMRdFTGJqoF/0kpLqMrbZx0vxSSm8wUjCYep4sccVBiU+rJ8MxwBEoTePn0H6Rwkj68BLbU8fv234xpu7BhgPB8rvbS3TlJPbEmebMMk+vObg9BNEtIZEQzDDc/o3wYor17gZ9qs/YtAaxYq7snIVBi7dsBn9p5+bpgwr4ahTf2Pbdqol3K4vFngnBdUu4a4aXG9r/XX94BCm2uGgS+00EaA97NDesCLBe8wM066qJ7QJQQ5y3PLQmQK5CNrr8QVblfLZL2nuZTxhgqqAcpTmqIwyl115XVi7WSmpH3LrZ4Qnp3BRS5+JWi878CkgJlN/o3P/bLkVMfWlG7NWqmW3kmN8oGLbOAUfpqIvzNeIHZ1HrKNQknLMIwPjvDm+90WGRlbWCYSdzpNbXAOnFAyvOSxv3b1rHX/J7unUfxbmYKH3u4k+GQdEqQ5TK9BWkZO1aFIx3hIT+SsLfYuevlG0REZoHcHpI7jyNQJ6uXXS1+BJieyKCdFw6F3HLzRVBLRvWb5MRONC/UgEyHtDT1497zOcqFvu1TMP+8ErmgCntOMogAAAATQZ5BQhn/AAHOkkhIgDdGJeQYbQAAABMBnmJEL/8AAdfbiqAwkToWaU1wAAAB8EGaZzRMQ7/6WAAB6uyTjIC7x51llnxEQkABc/9109QuwqpE3cxXZLCZt9NmEjru/c6q8fezM1fQ30YkS6ALnylYzU2ZQ/Q/E1Is2PP+AuuBftAOWWbtVmeAz8Vr1NyjLJy9ceNLxZJi6Tj6GOCEpd2ocrsNweGqwqX+3gGDhb7ROqKgrp1tdvsoMRrWQM944oAZnncJld9LbkzK94asNapgNb2QHElflSGWHNSinCIwE1QMM5i0wZjLi1eiSdA/n/0H5iU2WoiaaRSbJ/liPLJHFj26uK1AULYUIzrNxfn2FLOX02+pjGmY/tnLVE0xigDaaOPFucUkz73awU8FpZY1jQa5DV5ofb5caIExhh+6EsVe1lXNTKNU3QSbZk30Vl3AuJePS50LVQ9DRmtT1psjO2oPdd92xMkPAv3BCOnDdOcmu+Vaf9oCJ+QAslk4yz8RULyRGbi9XOY88SoWcQ55dCj9hPrMkP2ZWtGttcAic52j+gW2GZQM+Pse5DBsS4XHm6u6M7GzCLfkOasaUrYGdI4qkxtUj/1yzAQNnes8g3ZiJaBwkRrCC5kkQhRSnpgEsSmY0y4chtYv8cF3j/YxgXbIfv32FPegkFPORNBPo6PgI/vB6qeDZjM+oWGF7knyHuKJvsyEFE997tqlVV0AAAAmQZ6FRREsM/8AA7SV0AHpJvGn70jxEUttht90eN9s9wGjr/paRsEAAAAQAZ6kRC//AAIrzntv68HgwQAAAAoBnqZEL/8AAEvBAAAB1EGaqzRMQz/kQAAMhSU5UQkuqsIAf4Ci3B62zC7KFLj/LMAYi+0GF7g1piADLytbSLTFWgIVSE419tTwZJq+UMuvaVTmZeeLoAZ0PliutCB0W94ORHwAKYmM2EceA9bpUjL5Iz+FAdFfJZ3lKCS5LTe+ErFuqyi8ykBvdhKSRlGg4SDloovpf63Ba5WjJV2o6/IwYTkUoyOYAUW99MmC4fkhhd27U893tRTloZE+aBR/0wOOKR7gKyrvoPaMG679ERTscliTxsmNNt6AndHL44sxHaVa7jvBC5Ki+/bHWwO2eOd8eHDpP3zVcLPKesIhsYjBowDDyBydLT6dSjOVdyeut/TxNW2TJPzBqSdA86aX5erPruT0ch5nMPNf0mOeBzwYBwD8UAOgPLoYJj4xJyBL43I/8zC9yu3Q163xSqGawxJchtl4hajiIppGZEKef7duLAcTPOFPxeCq0BoNrWI8q8XCczIHrAVWdqusYQ7AhZA2Fr626c9nj1fgt+eoK7qgYO1iJTecBFt0xsdojAv37fMbunVSfdIVht4khfligCXsoUfabsMPYGzqR8x3fUPfbLiplwOjbv1HDnsgpoD6nU0dbCFhi8RUCdzqBvd22pVbMAAAACtBnslFFSwz/wACoWOnD75kKfIlAAkd9WUQtvvr6OE8BS6tM/XZd/3Vu1JgAAAADwGe6EQv/wAEeyoAAhObDQAAABMBnupEL/8AAcMbEBkpswAJKStYAAABWUGa7TRMomF/hwAAL/Cw+/tK0Asib0EAT2i9Uv6swru3ubCpCaGRE0Hs7uVQ/re7IHK/aNM03FgvFyi4OkxL0PTg4A6RDJMeLNtJMv3z0PMnZiBvmG/fflcuBr2fa4JWdTHX5dvs1T5lYM8pZoqWtuT2BxwCfEcrCLB/CuFIGvSY1HarNEG1vxXfXu+HrZsMoWcRiWUz90a0z0Q5TfMhnPgrX1bm4KoA1KGE0t+OMEnoXd8JgDEbkeCBTMnhrcbNJa5VPL/LuTxuqYqbT0WT2yCBrd26iY9YeJENRXLSywfbcLnW2mueLW7oQzKmFzdyyqTy+rbd6LmhCoXkO5aTpLFFlpLjQWWYsr+ZF44d77KOEDQSS+YCcSp2/CEs6VFJfS7pKLBOkPGukaGoOIKKDtTA14D4HeUHXah0AgSS7l+kb1Rasbv2nC8n1n8LRwUJ0HaDQUZOsgi8IwAAAA0BnwxEL/8ACE6KrCBBAAABIEGbDjkxDP/kQAAWzj78/euq1FVP1uQqABzd7YXIg+d5l6TeveG6NxMUkYLJU1jfuKxIUd+FWgr6ISTJP/NaM+1zs8XnxI85lhR/RyyVA3daJI/LsbG76tSaTSR7XtfDcCuPZQfGWe07FtPKu1wi5Mf4wVLSxDRqcq6zPt1Wfa/9O6ENR+Mkm3vS/R9x2VU8Df4irj/+rB2C4w6zBnNrwL0AbpXe6wwGDhQhpbAvGmaWhUt0FYevVvi3LdATNdwlCxLVv/RGfuMIJKGXHp+gAAADARnFBsqMHkp4SXQOHxXL2UQ2FVdl7vQClnicrZ2J/tnjE6X9t9ucSgqMmTZUcbXdAVfWQ18HGAxR35nMD1iiDkE/hfdnb3OXOAnPuuywkQAAAdFBmzA5MpomGf/kQAHce60cwA/hHUlEQwjtRtZp/F9JLxWFPd9KDugMw/orpbVi+3wB8krs7/bNkXKjEFjE2nxv99NRwWiS/meKwMUyRnGuhCd3oyIWKiYJ9TTFvGKI556No7zuVTlchH0XlWiVqtd/d2utmrC/GMIrV5LwnC2oy0Qzk+pbtg2pRw4miAPjFYckdWRahC11Qa/xG43Wn2/NdubriTzx2sZhDNU5SJPqZ0aSUTTHpZyR5LgGRcfgEsKDRNh4FSgUiLuGPcwsXL8GEsgDLmqSTcTz2Gj1uTD0V7YVZPf+8eWJTZk4PCADFOvMb89kXefKzmc7t4VmQTk037Sf3+NNiikrplj3+AB2FhN5YJodz6iqw7Hf6HQeR86NosB6yUdx8aC6PGCCh4ADOPDnI+iNPgqyjGaIZKLUWIRQ3BnitEtXiAjKU3sxvWdM0fVFsHuMnqJ4xdAXDbAvtYIZ+ckggIOa/lGFkacoIvGCYffPss1M2T28XmtDSAj+v0ilOWmTIjhwFhys3xAIxfcfPQ0XhPwWw6+toy4dugcMMG6Uay7zf6kVqFDAnOn3Y5hPpLfCPf6BSz3plKza9pvdU1ibnvYpGPTUL1TLSEEAAAATAZ9PRC//ALVHef/CTqABAJtSkAAAAe1Bm1QYhn/kQADybmxEBLOkkIXTTWF+lIeouco2BThJblfInw1ICiTXpO2PnB4K1v4RfuJ8Lcsgou92lFPOUk7CNJdPgOUJGVFTYe58Kinhf22tTOPMOzHwyeUn8cuckDHk1vxqIy1uwVlKIqOqBKPhelnTZt0zvSWAKxhd1RPgTp/qxj3dGOq54i+1HsfHGFbgLl5ML1GHtzy1C7gP58aFFlVJWSPkaom91gAbutB3UKeUjpMUuU+PfF2nISh+dLTSNl20FZMMjD7Aduqznpn6GEhj6V9gPCgxiQdn00ygaMVk+Qw3G3SpbxrdZmGwtRhu7LRt5V5elHbKHNa3AZkIHWwj2n70/EhFkXnAv/NfalxseuMumZKAWZfzblMUbgFWse43K+y6yi8+hnXsQXmBtfnfXSswjaLJKazBpKSxV0dSlpBwaPvC8OeLz8iP8pCVzVEaq81NwKeefaM5QRV6d+L2SSsS9Q9EeO2mAr+pEbR/r4dy9/IiErWxOOE4JhJGppD5JvDc+2WQ/gxbpevuKBkEa0G57s5ELES2IDlOZitqVRLYWKOikAGh/DdWK/EhIveXuVhuiFTgwN+W5LseJjh1HY0J0nV7dSI66gFZAhUCQjXQtO8RNImBMJ/DtEdRLn7Fqjh/vu2qZbtgAAAASkGfckURPDP/AAO5YxACu9bU/r+D3exFT9L4ilZ3doVtCcBczp7KSvnwX44tAEug74jkN5rmZBO+1gjunnoCqBhILyka+QPF9mVBAAAAFwGfkUQv/wBdcdcibHVpSe4wHZo3gCSlAAAACgGfk0Qv/wAAS8AAAAFtQZuXNExDP+RAABP+T0Srp13dV8RiYUkC6wVhgrCNupZaz+IwEstPh32mClJ6yPyReVphi9ees7i891t3BAvFbgO5+jYGYiI7Qn5c4WieGTWzcuibZgMSbDPegHEnwxcfPCTt6JwAcg9zFt5nEoL5DAFqxj561y9eMbpriqPyXbQC4MohFayMpvbbE2RjnL/XPg4igHfEwMXFrQdp6zlblociZxu/hjZECjqsrjsBtsxhicH9mG6E/B/yfzbBorPpeR8o0EZyfZM+Z/K/KIV95rpNFKl1OaSO870XU9UIQ4P6gp3qwanMqLBpOEcU/xSj3oX8nLuf0nXNoHQkKKAOS17PeI5Pk2Ib/Ihn41FLpBp7IOked+7nOfgXBvmBg6Bd/uc9R3qZQv7zqSFGxuscjsQnlLtBcUnWxAkAEcCpP7pN4kN8QrS7VNa3+mY6GEnTNax0kPoY1Gj/3w8vqaPaWOar7KBObGRPtdIEtoEAAAAYQZ+1RREsM/8AAbCVjcxAMt84bxcmYgaBAAAADAGf1kQv/wABWBFnUwAAAaFBm9s0TEM/5EAADIUkHwhdoAEY5xdZ+VYIrRqil/nPmrfqXz2/WSfXrEGaP18yDTz7Sex1mVp7CVDybi/zz5492l25eKhpxO7tkhLSy8taQMw2gfJ2nB1H8bKIJIXXV5ULeokwP9jsZbRxGa9hQaUIrDEZwkBSVgzuryoZU+hcNjdacmylwLCRxSjVQE/+ViAQ3BLc2Gf3beFAd74Vkwd/cH8QlHOeo3W9sYkj/3m7SQrIlThY1J3sqtcdIwmaIgBcDSJeSNPAyaORYzEGDk/fGsoMxPzymrdUXshH+5hH3Ce0AKyerXG4RQF/fsMbQmyS+HFIaM+0VvdXk2a0Uw8pzQCXJzrwFsFZsZBEZT7kBqHL53xhtBo+d2J3XFcoO67gM7aifCV+HMJ+4qrDlq7NNMh4gr6tTwAiy4SRr2aPJJswrT9lBOw6xNwuKmA2iCkrtM76xAzttgAH2qQ9ZjdgxdwmVlU+DA1UgvowrOiClFtmtmd02lTZ/Rd/dAgaNaAy9i6pjjQ+NM0dJhHDc/ErzevNEB3WDyLhKUfe921TL3sAAAA3QZ/5RRUsM/8AA3XcyAIYHmMtXNWAXVvIxNDPUcpmq+aftYk3xjBsTCPn/7g4J8rmVCxUShQWgAAAAA0BnhhEL/8AAbiduEbBAAAAFQGeGkQv/wACbZUAAbkKOTBuGX7pgAAAAQ5Bmh00TKJhf4cAAC/wovuzEAJhC2xzaTlQa8TQVnT7Sa4/t1SGJJixnwt4szsF4+MfYwtJiOIvdGuTRNHLHjX/qk7r2ztPeeFWGISvjCOZezetlJ7jYA5oiLDR4YzAeAtLsEvFDW/iSYCNcelU8HW9x8ZBlnG40uzNQTLZ6QqKzc2vEm2RjIN3nUAqLf1U//yyvefHG+xBoiR3cLyw8Dt9DBTe7kIwl7D22gcSSsQPXKULDcxN/qM2Es2tcR/rDHWxSA1GKSpcI8g12RqBA5XrzjM8ZmD2acObPknOYOLZgI0Vlt3lrq6RnBNIajb5AHDUp8p602ADXhjpELU9t33fBNWFnIkgxqaialyJ0WEAAAAKAZ48RC//AABLwQ==';

/**
 * Mengonversi base64 ke Blob biner asli dengan fallback aman
 */
export function base64ToBlob(base64: string, mimeType: string): Blob {
  try {
    // Bersihkan karakter non-base64 jika ada
    const cleanB64 = base64.replace(/[^A-Za-z0-9+/=]/g, '');
    const paddedB64 = cleanB64.padEnd(cleanB64.length + ((4 - (cleanB64.length % 4)) % 4), '=');
    const byteChars = atob(paddedB64);
    const byteArray = new Uint8Array(byteChars.length);
    for (let i = 0; i < byteChars.length; i++) {
      byteArray[i] = byteChars.charCodeAt(i);
    }
    return new Blob([byteArray], { type: mimeType });
  } catch (err) {
    console.warn('Fallback base64ToBlob error:', err);
    return new Blob([], { type: mimeType });
  }
}

/**
 * Mengonversi base64 ke ArrayBuffer biner asli dengan fallback aman
 */
export function base64ToArrayBuffer(base64: string): ArrayBuffer {
  try {
    const cleanB64 = base64.replace(/[^A-Za-z0-9+/=]/g, '');
    const paddedB64 = cleanB64.padEnd(cleanB64.length + ((4 - (cleanB64.length % 4)) % 4), '=');
    const byteChars = atob(paddedB64);
    const len = byteChars.length;
    const bytes = new Uint8Array(len);
    for (let i = 0; i < len; i++) {
      bytes[i] = byteChars.charCodeAt(i);
    }
    return bytes.buffer;
  } catch (err) {
    console.warn('Fallback base64ToArrayBuffer error:', err);
    return new ArrayBuffer(0);
  }
}

/**
 * Mengembalikan Blob video MP4 asli yang dijamin dapat diputar di semua browser & Android
 */
export function getRealPlayableVideoBlob(): Blob {
  return base64ToBlob(REAL_MP4_BASE64, 'video/mp4');
}

/**
 * Mengembalikan ArrayBuffer video MP4 asli
 */
export function getRealPlayableVideoArrayBuffer(): ArrayBuffer {
  return base64ToArrayBuffer(REAL_MP4_BASE64);
}

/**
 * Generator foto berwarna nyata dengan raster piksel hidup (bukan blank/hitam)
 */
export function createVibrantTestPhotoBuffer(
  width: number,
  height: number,
  title: string,
  category: 'PANTAI' | 'KELUARGA' | 'DOKUMEN' | 'THUMBNAIL'
): ArrayBuffer {
  try {
    if (typeof document === 'undefined') {
      return new ArrayBuffer(0);
    }
    const canvas = document.createElement('canvas');
    canvas.width = width;
    canvas.height = height;
    const ctx = canvas.getContext('2d');
    if (!ctx) return new ArrayBuffer(0);

    if (category === 'PANTAI') {
      // Gradien senja langit pantai
      const sky = ctx.createLinearGradient(0, 0, 0, height * 0.65);
      sky.addColorStop(0, '#f97316');   // orange senja
      sky.addColorStop(0.4, '#fbbf24'); // kuning emas
      sky.addColorStop(1, '#0284c7');   // biru laut horizon
      ctx.fillStyle = sky;
      ctx.fillRect(0, 0, width, height * 0.65);

      // Matahari terbenam
      ctx.beginPath();
      ctx.arc(width * 0.5, height * 0.55, width * 0.12, 0, Math.PI * 2);
      ctx.fillStyle = '#fef08a';
      ctx.shadowColor = '#fbbf24';
      ctx.shadowBlur = 30;
      ctx.fill();
      ctx.shadowBlur = 0;

      // Air laut
      const sea = ctx.createLinearGradient(0, height * 0.65, 0, height);
      sea.addColorStop(0, '#0369a1');
      sea.addColorStop(1, '#0c4a6e');
      ctx.fillStyle = sea;
      ctx.fillRect(0, height * 0.65, width, height * 0.35);
    } else if (category === 'KELUARGA') {
      // Suasana taman hijau cerah
      const garden = ctx.createLinearGradient(0, 0, width, height);
      garden.addColorStop(0, '#065f46');
      garden.addColorStop(0.5, '#047857');
      garden.addColorStop(1, '#064e3b');
      ctx.fillStyle = garden;
      ctx.fillRect(0, 0, width, height);

      // Bunga & aksen warna
      ctx.fillStyle = '#f43f5e';
      ctx.beginPath();
      ctx.arc(width * 0.25, height * 0.7, width * 0.08, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = '#eab308';
      ctx.beginPath();
      ctx.arc(width * 0.75, height * 0.65, width * 0.09, 0, Math.PI * 2);
      ctx.fill();
    } else {
      // Mode Dokumen / Thumbnail
      const bg = ctx.createLinearGradient(0, 0, width, height);
      bg.addColorStop(0, '#1e293b');
      bg.addColorStop(1, '#0f172a');
      ctx.fillStyle = bg;
      ctx.fillRect(0, 0, width, height);
    }

    // Header info pada foto
    ctx.fillStyle = 'rgba(15, 23, 42, 0.75)';
    ctx.fillRect(20, 20, width - 40, 90);

    ctx.fillStyle = '#ffffff';
    ctx.font = 'bold 22px sans-serif';
    ctx.fillText(title, 36, 54);

    ctx.fillStyle = '#38bdf8';
    ctx.font = '14px monospace';
    ctx.fillText('Dimensi: ' + width + 'x' + height + ' px | Pixel Verified: 100%', 36, 82);

    const dataUrl = canvas.toDataURL('image/jpeg', 0.95);
    const parts = dataUrl.split(',');
    if (parts.length < 2) return new ArrayBuffer(0);
    const byteString = atob(parts[1]);
    const ab = new ArrayBuffer(byteString.length);
    const ia = new Uint8Array(ab);
    for (let i = 0; i < byteString.length; i++) {
      ia[i] = byteString.charCodeAt(i);
    }
    return ab;
  } catch (err) {
    console.warn('Gagal membuat test photo buffer:', err);
    return new ArrayBuffer(0);
  }
}

export interface HexRow {
  offset: string;
  hex: string;
  ascii: string;
}

/**
 * Membaca buffer dan menghasilkan baris hex forensik (16 byte per baris)
 */
export function extractHexDump(buffer: ArrayBuffer | Uint8Array, maxBytes = 256): HexRow[] {
  try {
    const bytes = buffer instanceof Uint8Array ? buffer : new Uint8Array(buffer);
    const limit = Math.min(bytes.length, maxBytes);
    const rows: HexRow[] = [];

    for (let i = 0; i < limit; i += 16) {
      const offset = i.toString(16).padStart(8, '0').toUpperCase();
      const chunk = bytes.slice(i, Math.min(i + 16, limit));
      
      const hexArr: string[] = [];
      let ascii = '';
      
      for (let j = 0; j < 16; j++) {
        if (j < chunk.length) {
          hexArr.push(chunk[j].toString(16).padStart(2, '0').toUpperCase());
          const charCode = chunk[j];
          if (charCode >= 32 && charCode <= 126) {
            ascii += String.fromCharCode(charCode);
          } else {
            ascii += '.';
          }
        } else {
          hexArr.push('  ');
          ascii += ' ';
        }
      }
      
      rows.push({
        offset,
        hex: hexArr.join(' '),
        ascii
      });
    }

    return rows;
  } catch (err) {
    console.warn('Gagal extractHexDump:', err);
    return [];
  }
}
