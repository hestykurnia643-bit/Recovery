/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useMemo, useRef } from 'react';
import { TopBar } from './components/TopBar';
import { ScanControlCard } from './components/ScanControlCard';
import { MediaFilterBar } from './components/MediaFilterBar';
import { MediaGrid } from './components/MediaGrid';
import { PreviewModal } from './components/PreviewModal';
import { BottomActionBar } from './components/BottomActionBar';
import { RecoveryConfirmationModal } from './components/RecoveryConfirmationModal';
import { AndroidProjectModal } from './components/AndroidProjectModal';
import { TechnicalInfoModal } from './components/TechnicalInfoModal';
import { RecoveredMediaItem, ScanStats, MediaFormat, RecoveryTier } from './types';
import { scanAndroidRealStorage, scanRealFileSystem } from './services/recoveryEngine';
import { CheckCircle2, HardDrive, AlertCircle } from 'lucide-react';

export default function App() {
  const [items, setItems] = useState<RecoveredMediaItem[]>([]);
  const [isScanning, setIsScanning] = useState(false);
  const [hasScanned, setHasScanned] = useState(false);
  const [previewItem, setPreviewItem] = useState<RecoveredMediaItem | null>(null);
  const [isRecoveryModalOpen, setIsRecoveryModalOpen] = useState(false);
  const [isAndroidSourceModalOpen, setIsAndroidSourceModalOpen] = useState(false);
  const [isTechInfoModalOpen, setIsTechInfoModalOpen] = useState(false);
  const [notification, setNotification] = useState<string | null>(null);

  // Filters
  const [selectedType, setSelectedType] = useState<'all' | 'image' | 'video'>('all');
  const [selectedTier, setSelectedTier] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');

  // Scanning Stats State
  const [stats, setStats] = useState<ScanStats>({
    phase: 'idle',
    currentPath: 'Penyimpanan Internal / DCIM / Caches',
    progressPercent: 0,
    filesScanned: 0,
    activeGallerySkipped: 0,
    recoveredItemsFound: 0,
    fullValidCount: 0,
    partialCount: 0,
    headerCorruptCount: 0,
    thumbnailOnlyCount: 0,
    metadataOnlyCount: 0,
    unrecoverableCount: 0,
    totalRecoverableBytes: 0,
    elapsedSeconds: 0
  });

  const isCancelledRef = useRef(false);
  const elapsedTimerRef = useRef<NodeJS.Timeout | null>(null);

  // Cleanup object URLs on unmount to prevent RAM leaks
  useEffect(() => {
    return () => {
      if (elapsedTimerRef.current) clearInterval(elapsedTimerRef.current);
      items.forEach((item) => {
        if (item.previewUrl?.startsWith('blob:')) {
          URL.revokeObjectURL(item.previewUrl);
        }
      });
    };
  }, [items]);

  // Show temporary toast notification
  const showToast = (message: string) => {
    setNotification(message);
    setTimeout(() => {
      setNotification((prev) => (prev === message ? null : prev));
    }, 4500);
  };

  // Start Deep Scan Workflow
  const handleStartDeepScan = async () => {
    // Revoke old URLs
    items.forEach((item) => {
      if (item.previewUrl?.startsWith('blob:')) {
        URL.revokeObjectURL(item.previewUrl);
      }
    });

    setIsScanning(true);
    setHasScanned(false);
    isCancelledRef.current = false;
    setItems([]);

    setStats({
      phase: 'querying_mediastore',
      currentPath: 'MediaStore ContentResolver (Query IS_TRASHED)',
      progressPercent: 5,
      filesScanned: 0,
      activeGallerySkipped: 0,
      recoveredItemsFound: 0,
      fullValidCount: 0,
      partialCount: 0,
      headerCorruptCount: 0,
      thumbnailOnlyCount: 0,
      metadataOnlyCount: 0,
      unrecoverableCount: 0,
      totalRecoverableBytes: 0,
      elapsedSeconds: 0
    });

    // Start timer
    if (elapsedTimerRef.current) clearInterval(elapsedTimerRef.current);
    elapsedTimerRef.current = setInterval(() => {
      setStats((prev) => ({ ...prev, elapsedSeconds: prev.elapsedSeconds + 1 }));
    }, 1000);

    try {
      const result = await scanAndroidRealStorage(
        (progressUpdate) => {
          setStats((prev) => ({ ...prev, ...progressUpdate }));
        },
        () => isCancelledRef.current
      );

      if (elapsedTimerRef.current) clearInterval(elapsedTimerRef.current);

      if (isCancelledRef.current) {
        setIsScanning(false);
        setStats((prev) => ({
          ...prev,
          phase: 'cancelled',
          currentPath: 'Scan Dibatalkan oleh Pengguna'
        }));
        showToast('Pemindaian dihentikan.');
        return;
      }

      setItems(result.recovered);
      setHasScanned(true);

      const fullValidCount = result.recovered.filter((i) => i.tier === 'FULL_VALID').length;
      const partialCount = result.recovered.filter((i) => i.tier === 'PARTIAL').length;
      const headerCorruptCount = result.recovered.filter((i) => i.tier === 'HEADER_ONLY/CORRUPT').length;
      const thumbnailOnlyCount = result.recovered.filter((i) => i.tier === 'THUMBNAIL_ONLY').length;
      const metadataOnlyCount = result.recovered.filter((i) => i.tier === 'METADATA_ONLY').length;
      const unrecoverableCount = result.recovered.filter((i) => i.tier === 'UNRECOVERABLE').length;

      const totalRecoverableBytes = result.recovered
        .filter((i) => i.canRecover)
        .reduce((acc, curr) => acc + curr.sizeBytes, 0);

      setStats((prev) => ({
        ...prev,
        phase: 'completed',
        progressPercent: 100,
        currentPath: `Audit Selesai: ${fullValidCount} FULL_VALID, ${thumbnailOnlyCount} THUMB, ${headerCorruptCount} KORUP`,
        activeGallerySkipped: result.skippedActiveCount,
        recoveredItemsFound: result.recovered.length,
        fullValidCount,
        partialCount,
        headerCorruptCount,
        thumbnailOnlyCount,
        metadataOnlyCount,
        unrecoverableCount,
        totalRecoverableBytes
      }));

      setIsScanning(false);
      showToast(
        `Hasil Diagnostik: ${fullValidCount} FULL_VALID (Terdekode), ${thumbnailOnlyCount} THUMBNAIL, ${partialCount} PARTIAL, ${headerCorruptCount} HEADER_ONLY (Korup), ${metadataOnlyCount} METADATA, ${result.skippedActiveCount} Galeri Aktif Dilewati.`
      );
    } catch (err: any) {
      console.error('Scan error:', err);
      if (elapsedTimerRef.current) clearInterval(elapsedTimerRef.current);
      setIsScanning(false);
      const msg = err?.message || 'Terjadi kesalahan saat pemindaian.';
      showToast(`Gagal memindai: ${msg}`);
    }
  };

  // Cancel Scan
  const handleCancelScan = () => {
    isCancelledRef.current = true;
    if (elapsedTimerRef.current) clearInterval(elapsedTimerRef.current);
    setIsScanning(false);
    setStats((prev) => ({
      ...prev,
      phase: 'cancelled',
      currentPath: 'Scan Dibatalkan oleh Pengguna'
    }));
    showToast('Pemindaian dihentikan.');
  };

  // Reset Scan
  const handleResetScan = () => {
    handleCancelScan();
    // Free RAM
    items.forEach((item) => {
      if (item.previewUrl?.startsWith('blob:')) {
        URL.revokeObjectURL(item.previewUrl);
      }
    });

    setItems([]);
    setHasScanned(false);
    setStats({
      phase: 'idle',
      currentPath: 'Penyimpanan Internal / DCIM / Caches',
      progressPercent: 0,
      filesScanned: 0,
      activeGallerySkipped: 0,
      recoveredItemsFound: 0,
      fullValidCount: 0,
      partialCount: 0,
      headerCorruptCount: 0,
      thumbnailOnlyCount: 0,
      metadataOnlyCount: 0,
      unrecoverableCount: 0,
      totalRecoverableBytes: 0,
      elapsedSeconds: 0
    });
  };

  // Physical Folder / SD Card / MTP Scan via real file carver
  const handleSelectLocalFolder = async (fileList: FileList | File[]) => {
    const rawFiles = Array.isArray(fileList) ? fileList : Array.from(fileList);
    if (rawFiles.length === 0) return;

    // Free RAM
    items.forEach((item) => {
      if (item.previewUrl?.startsWith('blob:')) {
        URL.revokeObjectURL(item.previewUrl);
      }
    });

    setIsScanning(true);
    setHasScanned(false);
    isCancelledRef.current = false;
    setItems([]);

    setStats({
      phase: 'scanning_thumbnail_db',
      currentPath: `Menganalisis ${rawFiles.length} file dari folder fisik...`,
      progressPercent: 10,
      filesScanned: 0,
      activeGallerySkipped: 0,
      recoveredItemsFound: 0,
      fullValidCount: 0,
      partialCount: 0,
      headerCorruptCount: 0,
      thumbnailOnlyCount: 0,
      metadataOnlyCount: 0,
      unrecoverableCount: 0,
      totalRecoverableBytes: 0,
      elapsedSeconds: 0
    });

    if (elapsedTimerRef.current) clearInterval(elapsedTimerRef.current);
    elapsedTimerRef.current = setInterval(() => {
      setStats((prev) => ({ ...prev, elapsedSeconds: prev.elapsedSeconds + 1 }));
    }, 1000);

    try {
      const result = await scanRealFileSystem(
        rawFiles,
        (progressUpdate) => {
          setStats((prev) => ({ ...prev, ...progressUpdate }));
        },
        () => isCancelledRef.current
      );

      if (elapsedTimerRef.current) clearInterval(elapsedTimerRef.current);

      if (isCancelledRef.current) {
        setIsScanning(false);
        setStats((prev) => ({ ...prev, phase: 'cancelled' }));
        return;
      }

      setItems(result.recovered);
      setHasScanned(true);

      const fullValidCount = result.recovered.filter((i) => i.tier === 'FULL_VALID').length;
      const partialCount = result.recovered.filter((i) => i.tier === 'PARTIAL').length;
      const headerCorruptCount = result.recovered.filter((i) => i.tier === 'HEADER_ONLY/CORRUPT').length;
      const thumbnailOnlyCount = result.recovered.filter((i) => i.tier === 'THUMBNAIL_ONLY').length;
      const metadataOnlyCount = result.recovered.filter((i) => i.tier === 'METADATA_ONLY').length;
      const unrecoverableCount = result.recovered.filter((i) => i.tier === 'UNRECOVERABLE').length;

      const totalRecoverableBytes = result.recovered
        .filter((i) => i.canRecover)
        .reduce((a, b) => a + b.sizeBytes, 0);

      setStats((prev) => ({
        ...prev,
        phase: 'completed',
        progressPercent: 100,
        currentPath: `Selesai: ${result.recovered.length} jejak dianalisis (${fullValidCount} FULL_VALID, ${thumbnailOnlyCount} THUMB)`,
        filesScanned: rawFiles.length,
        activeGallerySkipped: result.skippedActiveCount,
        recoveredItemsFound: result.recovered.length,
        fullValidCount,
        partialCount,
        headerCorruptCount,
        thumbnailOnlyCount,
        metadataOnlyCount,
        unrecoverableCount,
        totalRecoverableBytes
      }));

      setIsScanning(false);
      showToast(
        `Hasil Analisis: ${fullValidCount} FULL_VALID, ${thumbnailOnlyCount} THUMBNAIL, ${headerCorruptCount} KORUP, ${result.skippedActiveCount} foto aktif galeri dilewati.`
      );
    } catch (err) {
      console.error('Folder scan error:', err);
      if (elapsedTimerRef.current) clearInterval(elapsedTimerRef.current);
      setIsScanning(false);
      showToast('Gagal memindai folder.');
    }
  };

  // Toggle selection
  const handleToggleSelect = (id: string, e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    setItems((prev) =>
      prev.map((item) => (item.id === id ? { ...item, selected: !item.selected } : item))
    );
  };

  // Toggle Select All (only for recoverable items)
  const handleToggleSelectAll = () => {
    const recoverableFiltered = filteredItems.filter((i) => i.canRecover);
    const areAllSelected =
      recoverableFiltered.length > 0 && recoverableFiltered.every((item) => item.selected);
    const targetState = !areAllSelected;
    const recoverableIds = new Set(recoverableFiltered.map((item) => item.id));

    setItems((prev) =>
      prev.map((item) => (recoverableIds.has(item.id) ? { ...item, selected: targetState } : item))
    );
  };

  // Clear all selections
  const handleClearSelection = () => {
    setItems((prev) => prev.map((item) => ({ ...item, selected: false })));
  };

  // Recover Single Item from Preview Modal
  const handleRecoverSingle = (item: RecoveredMediaItem) => {
    if (!item.canRecover) return;
    setItems((prev) =>
      prev.map((i) => (i.id === item.id ? { ...i, selected: true } : i))
    );
    setIsRecoveryModalOpen(true);
  };

  // Confirm and Execute Recovery
  const handleConfirmRecovery = () => {
    const selectedIds = new Set(selectedItems.map((i) => i.id));
    setItems((prev) =>
      prev.map((item) =>
        selectedIds.has(item.id)
          ? { ...item, recovered: true, selected: false, recoveredAt: new Date().toLocaleTimeString() }
          : item
      )
    );
    showToast(
      `Sukses! ${selectedItems.length} media berhasil dipulihkan ke /Pictures/Recovered_Media/`
    );
  };

  // Filtered Items logic
  const filteredItems = useMemo(() => {
    return items.filter((item) => {
      // Type filter
      if (selectedType !== 'all' && item.type !== selectedType) return false;

      // Tier filter
      if (selectedTier !== 'all' && item.tier !== selectedTier) return false;

      // Search Query
      if (searchQuery.trim()) {
        const query = searchQuery.toLowerCase();
        const matchName = item.name.toLowerCase().includes(query);
        const matchFormat = item.format.toLowerCase().includes(query);
        const matchSource = item.sourceDescription.toLowerCase().includes(query);
        if (!matchName && !matchFormat && !matchSource) return false;
      }

      return true;
    });
  }, [items, selectedType, selectedTier, searchQuery]);

  const selectedItems = useMemo(() => items.filter((item) => item.selected && item.canRecover), [items]);

  const recoverableFiltered = filteredItems.filter((i) => i.canRecover);
  const allFilteredSelected =
    recoverableFiltered.length > 0 && recoverableFiltered.every((item) => item.selected);
  const someFilteredSelected =
    recoverableFiltered.some((item) => item.selected) && !allFilteredSelected;

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col selection:bg-cyan-500 selection:text-slate-950">
      {/* Top Bar Navigation */}
      <TopBar
        onOpenSourceModal={() => setIsAndroidSourceModalOpen(true)}
        onOpenInfoModal={() => setIsTechInfoModalOpen(true)}
      />

      {/* Main Container */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-4 sm:p-6 lg:p-8 space-y-6">
        {/* Toast Notification Banner */}
        {notification && (
          <div className="bg-gradient-to-r from-emerald-950 to-slate-900 border border-emerald-600/60 p-3.5 rounded-xl shadow-lg flex items-center justify-between animate-in fade-in slide-in-from-top-3 duration-200">
            <div className="flex items-center space-x-2.5 text-xs font-semibold text-emerald-300">
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
              <span>{notification}</span>
            </div>
            <button
              onClick={() => setNotification(null)}
              className="text-slate-400 hover:text-white text-xs px-2 py-0.5"
            >
              ✕
            </button>
          </div>
        )}

        {/* Scan Control Card */}
        <ScanControlCard
          stats={stats}
          isScanning={isScanning}
          onStartDeepScan={handleStartDeepScan}
          onCancelScan={handleCancelScan}
          onResetScan={handleResetScan}
          onSelectLocalFolder={handleSelectLocalFolder}
          hasResults={items.length > 0}
        />

        {/* Filter and Selection Controls */}
        {items.length > 0 && (
          <MediaFilterBar
            selectedType={selectedType}
            onSelectType={setSelectedType}
            selectedTier={selectedTier}
            onSelectTier={setSelectedTier}
            searchQuery={searchQuery}
            onSearchChange={setSearchQuery}
            allSelected={allFilteredSelected}
            someSelected={someFilteredSelected}
            onToggleSelectAll={handleToggleSelectAll}
            totalFilteredCount={filteredItems.length}
            totalSelectedCount={selectedItems.length}
          />
        )}

        {/* Results Media Grid */}
        <section className="space-y-3">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold text-slate-200 flex items-center space-x-2">
              <HardDrive className="w-4 h-4 text-cyan-400" />
              <span>
                {items.length > 0
                  ? `Hasil Audit Jejak Media (${filteredItems.length} dari ${items.length} file)`
                  : hasScanned
                  ? 'Hasil Pemindaian Selesai'
                  : 'Siap Melakukan Deep Scan'}
              </span>
            </h3>

            {items.length > 0 && (
              <span className="text-[11px] text-slate-400 hidden sm:inline">
                FULL = Foto/Video Asli • THUMB ONLY = Cache Sistem • METADATA = Sektor Kosong
              </span>
            )}
          </div>

          <MediaGrid
            items={filteredItems}
            onToggleSelect={handleToggleSelect}
            onPreview={(item) => setPreviewItem(item)}
            hasScanned={hasScanned}
            skippedActiveCount={stats.activeGallerySkipped}
          />
        </section>
      </main>

      {/* Floating Bottom Bar for Bulk Action */}
      <BottomActionBar
        selectedItems={selectedItems}
        onOpenRecoveryModal={() => setIsRecoveryModalOpen(true)}
        onClearSelection={handleClearSelection}
      />

      {/* Fullscreen Preview Modal */}
      <PreviewModal
        item={previewItem}
        onClose={() => setPreviewItem(null)}
        onToggleSelect={(id) => handleToggleSelect(id)}
        onRecoverSingle={handleRecoverSingle}
      />

      {/* Recovery Confirmation Modal */}
      <RecoveryConfirmationModal
        items={selectedItems}
        isOpen={isRecoveryModalOpen}
        onClose={() => setIsRecoveryModalOpen(false)}
        onConfirmRecovery={handleConfirmRecovery}
      />

      {/* Native Android Project Source Code & APK Export Modal */}
      <AndroidProjectModal
        isOpen={isAndroidSourceModalOpen}
        onClose={() => setIsAndroidSourceModalOpen(false)}
      />

      {/* Technical Limitations & Non-Root Forensics Info Modal */}
      <TechnicalInfoModal
        isOpen={isTechInfoModalOpen}
        onClose={() => setIsTechInfoModalOpen(false)}
      />
    </div>
  );
}
