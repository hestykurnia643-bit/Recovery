export type MediaFormat = 'JPG' | 'JPEG' | 'PNG' | 'WEBP' | 'HEIC' | 'MP4' | 'MOV';

export type RecoveryTier =
  | 'FULL_VALID'
  | 'PARTIAL'
  | 'HEADER_ONLY/CORRUPT'
  | 'THUMBNAIL_ONLY'
  | 'METADATA_ONLY'
  | 'UNRECOVERABLE';

export type QualityEstimate =
  | 'Utuh (Data Asli Valid & Terdekode)'
  | 'Baik (Resolusi Penuh)'
  | 'Thumbnail Saja (Resolusi Rendah)'
  | 'Fragment Rusak / Sebagian'
  | 'Hanya Header / Data Korup'
  | 'Hanya Metadata (Data Fisik Kosong)'
  | 'Tidak Dapat Dipulihkan';

export interface MediaMetadata {
  camera?: string;
  resolution?: string;
  duration?: string;
  codec?: string;
  bitrate?: string;
  dateDeletedEstimate?: string;
  originalPath?: string;
  storagePartition?: string;
  clusterOffset?: string;
  magicHeader?: string;
  colorSpace?: string;
  recoveredBytes?: number;
  unrecoverableReason?: string;
  decoderTested?: boolean;
  decoderStatus?: 'SUCCESS' | 'DECODE_ERROR' | 'MISSING_PAYLOAD' | 'NO_VIDEO_TRACK';
  decoderMessage?: string;
  pixelVariance?: number;
}

export interface RecoveredMediaItem {
  id: string;
  name: string;
  type: 'image' | 'video';
  format: MediaFormat;
  sizeBytes: number;
  formattedSize: string;
  timestamp: string;
  tier: RecoveryTier;
  quality: QualityEstimate;
  integrityScore: number; // 0 - 100
  isCorrupted: boolean;
  isFragment: boolean;
  canPreview: boolean;
  canRecover: boolean;
  sourceType: 'thumbnail_cache' | 'trash_residual' | 'app_cache' | 'lost_dir' | 'unlinked_inode' | 'mediastore_orphan';
  sourceDescription: string;
  previewUrl: string;
  videoUrl?: string;
  blob?: Blob;
  metadata: MediaMetadata;
  selected: boolean;
  recovered: boolean;
  recoveredAt?: string;
}

export type ScanPhase =
  | 'idle'
  | 'querying_mediastore'
  | 'filtering_active_gallery'
  | 'scanning_trash_residuals'
  | 'scanning_thumbnail_db'
  | 'carving_raw_thumbdata'
  | 'carving_lost_dir_fragments'
  | 'verifying_headers'
  | 'testing_decoders'
  | 'completed'
  | 'cancelled';

export interface ScanStats {
  phase: ScanPhase;
  currentPath: string;
  progressPercent: number;
  filesScanned: number;
  activeGallerySkipped: number;
  recoveredItemsFound: number;
  fullValidCount: number;
  partialCount: number;
  headerCorruptCount: number;
  thumbnailOnlyCount: number;
  metadataOnlyCount: number;
  unrecoverableCount: number;
  totalRecoverableBytes: number;
  elapsedSeconds: number;
}

export interface AndroidSourceFile {
  name: string;
  path: string;
  language: 'kotlin' | 'xml' | 'groovy' | 'markdown';
  description: string;
  content: string;
}
