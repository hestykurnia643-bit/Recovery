import { MediaFormat, QualityEstimate, RecoveryTier } from '../types';
import { testImageDecoder, testVideoDecoder } from './decoderValidator';

export interface CarveResult {
  format: MediaFormat;
  type: 'image' | 'video';
  tier: RecoveryTier;
  quality: QualityEstimate;
  integrityScore: number;
  isCorrupted: boolean;
  canPreview: boolean;
  canRecover: boolean;
  resolution?: string;
  duration?: string;
  codec?: string;
  magicHeader: string;
  blob?: Blob;
  sizeBytes: number;
  unrecoverableReason?: string;
  decoderTested: boolean;
  decoderMessage?: string;
}

/**
 * Validasi biner mendalam menggunakan ImageDecoder & Video Demuxer
 * Membedakan secara nyata:
 * - FULL_VALID (Data asli valid dan terbukti dapat didekode)
 * - PARTIAL (Sebagian data tersedia)
 * - HEADER_ONLY/CORRUPT (Header ada tetapi payload tidak dapat didekode / blank)
 * - THUMBNAIL_ONLY (Hanya thumbnail cache resolusi rendah)
 * - METADATA_ONLY (Hanya baris metadata tanpa blok fisik)
 * - UNRECOVERABLE (Sektor rusak total)
 */
export async function analyzeBinaryHeader(
  buffer: ArrayBuffer,
  fileName: string,
  filePath: string
): Promise<CarveResult> {
  const bytes = new Uint8Array(buffer);
  const lowerPath = filePath.toLowerCase();
  const lowerName = fileName.toLowerCase();

  // 1. Kasus: File 0 Byte / Hanya record MediaStore
  if (bytes.length === 0) {
    return {
      format: 'JPG',
      type: 'image',
      tier: 'METADATA_ONLY',
      quality: 'Hanya Metadata (Data Fisik Kosong)',
      integrityScore: 0,
      isCorrupted: true,
      canPreview: false,
      canRecover: false,
      magicHeader: 'KOSONG (0 Bytes)',
      sizeBytes: 0,
      unrecoverableReason:
        'Sektor fisik telah di-zero out oleh TRIM flash storage saat trash dikosongkan. Hanya catatan nama & tanggal yang tersisa di MediaStore SQLite.',
      decoderTested: true,
      decoderMessage: 'Ukuran file 0 byte: Tidak ada byte fisik untuk didekode.'
    };
  }

  const isFromThumbnailDir =
    lowerPath.includes('.thumbnails') ||
    lowerName.startsWith('.thumbdata') ||
    lowerName.includes('thumb');

  // ==================== JPEG ====================
  if (bytes.length >= 3 && bytes[0] === 0xFF && bytes[1] === 0xD8 && bytes[2] === 0xFF) {
    let hasEoi = false;
    const scanLimit = Math.max(0, bytes.length - 256);
    for (let i = bytes.length - 2; i >= scanLimit; i--) {
      if (bytes[i] === 0xFF && bytes[i + 1] === 0xD9) {
        hasEoi = true;
        break;
      }
    }

    const blob = new Blob([buffer], { type: 'image/jpeg' });
    // JALANKAN TEST DECODER NYATA
    const decodeResult = await testImageDecoder(blob);

    if (!decodeResult.isValid) {
      // Header JPEG valid, tetapi decoder gagal merender piksel!
      return {
        format: 'JPG',
        type: 'image',
        tier: 'HEADER_ONLY/CORRUPT',
        quality: 'Hanya Header / Data Korup',
        integrityScore: 25,
        isCorrupted: true,
        canPreview: false,
        canRecover: false,
        magicHeader: 'FF D8 FF (Payload Rusak / Blank)',
        blob,
        sizeBytes: bytes.length,
        unrecoverableReason: decodeResult.errorMessage || 'Header JPEG ada tetapi payload tidak berisi data piksel valid.',
        decoderTested: true,
        decoderMessage: decodeResult.errorMessage
      };
    }

    const resolution = `${decodeResult.width} x ${decodeResult.height}`;
    const isSmallThumb = (decodeResult.width <= 400 && decodeResult.height <= 400) || isFromThumbnailDir;

    if (!hasEoi) {
      return {
        format: 'JPG',
        type: 'image',
        tier: 'PARTIAL',
        quality: 'Fragment Rusak / Sebagian',
        integrityScore: 50,
        isCorrupted: true,
        canPreview: true,
        canRecover: true,
        resolution,
        magicHeader: 'FF D8 FF (EOI Hilang / Truncated)',
        blob,
        sizeBytes: bytes.length,
        decoderTested: true,
        decoderMessage: 'Piksel terbaca sebagian hingga batas fragmen terputus.'
      };
    }

    if (isSmallThumb) {
      return {
        format: 'JPG',
        type: 'image',
        tier: 'THUMBNAIL_ONLY',
        quality: 'Thumbnail Saja (Resolusi Rendah)',
        integrityScore: 88,
        isCorrupted: false,
        canPreview: true,
        canRecover: true,
        resolution,
        magicHeader: 'FF D8 FF (Thumbnail Cache)',
        blob,
        sizeBytes: bytes.length,
        decoderTested: true,
        decoderMessage: `Decoder sukses: Thumbnail terverifikasi (${resolution} px).`
      };
    }

    // LULUS SEMUA VALIDASI: FULL_VALID
    return {
      format: 'JPG',
      type: 'image',
      tier: 'FULL_VALID',
      quality: 'Utuh (Data Asli Valid & Terdekode)',
      integrityScore: 100,
      isCorrupted: false,
      canPreview: true,
      canRecover: true,
      resolution,
      magicHeader: 'FF D8 FF E1 (JPEG Exif Intact)',
      blob,
      sizeBytes: bytes.length,
      decoderTested: true,
      decoderMessage: `Decoder sukses: Gambar asli terverifikasi (${resolution} px, variance ${decodeResult.pixelVariance}%).`
    };
  }

  // ==================== PNG ====================
  if (
    bytes.length >= 8 &&
    bytes[0] === 0x89 &&
    bytes[1] === 0x50 &&
    bytes[2] === 0x4E &&
    bytes[3] === 0x47
  ) {
    const blob = new Blob([buffer], { type: 'image/png' });
    const decodeResult = await testImageDecoder(blob);

    if (!decodeResult.isValid) {
      return {
        format: 'PNG',
        type: 'image',
        tier: 'HEADER_ONLY/CORRUPT',
        quality: 'Hanya Header / Data Korup',
        integrityScore: 25,
        isCorrupted: true,
        canPreview: false,
        canRecover: false,
        magicHeader: '89 50 4E 47 (IHDR Rusak / Blank)',
        blob,
        sizeBytes: bytes.length,
        unrecoverableReason: decodeResult.errorMessage || 'Payload PNG korup.',
        decoderTested: true,
        decoderMessage: decodeResult.errorMessage
      };
    }

    const resolution = `${decodeResult.width} x ${decodeResult.height}`;
    const isSmallThumb = (decodeResult.width <= 320 && decodeResult.height <= 320) || isFromThumbnailDir;

    return {
      format: 'PNG',
      type: 'image',
      tier: isSmallThumb ? 'THUMBNAIL_ONLY' : 'FULL_VALID',
      quality: isSmallThumb ? 'Thumbnail Saja (Resolusi Rendah)' : 'Utuh (Data Asli Valid & Terdekode)',
      integrityScore: isSmallThumb ? 88 : 100,
      isCorrupted: false,
      canPreview: true,
      canRecover: true,
      resolution,
      magicHeader: '89 50 4E 47 (PNG Valid)',
      blob,
      sizeBytes: bytes.length,
      decoderTested: true,
      decoderMessage: `Decoder sukses: PNG terverifikasi (${resolution} px).`
    };
  }

  // ==================== MP4 / MOV (Video) ====================
  if (bytes.length >= 12 && bytes[4] === 0x66 && bytes[5] === 0x74 && bytes[6] === 0x79 && bytes[7] === 0x70) {
    const brand = String.fromCharCode(bytes[8], bytes[9], bytes[10], bytes[11]);
    const isMov = brand.toLowerCase().includes('qt');
    const format: MediaFormat = isMov ? 'MOV' : 'MP4';
    const blob = new Blob([buffer], { type: isMov ? 'video/quicktime' : 'video/mp4' });

    // JALANKAN TEST DECODER VIDEO NYATA (Demuxer & Frame Verification)
    const videoDiagnosis = await testVideoDecoder(blob);

    if (!videoDiagnosis.isValid || !videoDiagnosis.hasDecodeableFrames) {
      return {
        format,
        type: 'video',
        tier: 'HEADER_ONLY/CORRUPT',
        quality: 'Hanya Header / Data Korup',
        integrityScore: 30,
        isCorrupted: true,
        canPreview: false,
        canRecover: false,
        magicHeader: `ftyp ${brand} (Box moov/mdat rusak)`,
        blob,
        sizeBytes: bytes.length,
        unrecoverableReason: videoDiagnosis.errorMessage || 'Video container tidak memiliki keyframe H.264 yang dapat didekode.',
        decoderTested: true,
        decoderMessage: videoDiagnosis.errorMessage
      };
    }

    const durationStr = `00:0${Math.max(1, Math.round(videoDiagnosis.duration))}`;
    const resolution = `${videoDiagnosis.width} x ${videoDiagnosis.height}`;

    return {
      format,
      type: 'video',
      tier: 'FULL_VALID',
      quality: 'Utuh (Data Asli Valid & Terdekode)',
      integrityScore: 100,
      isCorrupted: false,
      canPreview: true,
      canRecover: true,
      resolution,
      duration: durationStr,
      codec: videoDiagnosis.codec || 'H.264 / AVC',
      magicHeader: `ftyp ${brand} (Valid Stream)`,
      blob,
      sizeBytes: bytes.length,
      decoderTested: true,
      decoderMessage: `Media3/VideoDecoder sukses: Track video terverifikasi (${resolution}, durasi ${durationStr}).`
    };
  }

  // ==================== UNRECOVERABLE ====================
  return {
    format: 'JPG',
    type: 'image',
    tier: 'UNRECOVERABLE',
    quality: 'Tidak Dapat Dipulihkan',
    integrityScore: 10,
    isCorrupted: true,
    canPreview: false,
    canRecover: false,
    magicHeader: 'Byte Acak / Corrupted Sector',
    sizeBytes: bytes.length,
    unrecoverableReason: 'Blok data rusak total atau tertimpa data baru sehingga signature tidak dikenali.',
    decoderTested: true,
    decoderMessage: 'Format biner tidak dikenali.'
  };
}

/**
 * Carving JPEG dari container biner .thumbdata
 * Menghasilkan item dengan tier eksplisit: THUMBNAIL_ONLY
 */
export async function carveJpegFromThumbdata(buffer: ArrayBuffer, baseFileName: string): Promise<CarveResult[]> {
  const bytes = new Uint8Array(buffer);
  const carvedList: CarveResult[] = [];
  const minJpegSize = 2048;
  let offset = 0;

  while (offset < bytes.length - minJpegSize && carvedList.length < 25) {
    if (bytes[offset] === 0xFF && bytes[offset + 1] === 0xD8 && bytes[offset + 2] === 0xFF) {
      const startIndex = offset;
      let endIndex = -1;

      const maxSearch = Math.min(bytes.length - 2, startIndex + 5 * 1024 * 1024);
      for (let j = startIndex + 128; j < maxSearch; j++) {
        if (bytes[j] === 0xFF && bytes[j + 1] === 0xD9) {
          endIndex = j + 2;
          break;
        }
      }

      if (endIndex > startIndex && endIndex - startIndex >= minJpegSize) {
        const jpegBytes = bytes.slice(startIndex, endIndex);
        const blob = new Blob([jpegBytes], { type: 'image/jpeg' });
        const decodeResult = await testImageDecoder(blob);

        if (decodeResult.isValid) {
          carvedList.push({
            format: 'JPG',
            type: 'image',
            tier: 'THUMBNAIL_ONLY',
            quality: 'Thumbnail Saja (Resolusi Rendah)',
            integrityScore: 88,
            isCorrupted: false,
            canPreview: true,
            canRecover: true,
            resolution: `${decodeResult.width} x ${decodeResult.height} (Cache)`,
            magicHeader: 'FF D8 FF (Carved .thumbdata)',
            blob,
            sizeBytes: jpegBytes.length,
            decoderTested: true,
            decoderMessage: `Decoder sukses: Thumbnail cache terverifikasi (${decodeResult.width}x${decodeResult.height}).`
          });
        }
        offset = endIndex;
        continue;
      }
    }
    offset += 512;
  }

  return carvedList;
}

/**
 * Generator foto berwarna nyata yang terbukti memiliki piksel hidup (bukan blank/hitam)
 */
export function createVibrantTestPhotoBuffer(
  width: number,
  height: number,
  title: string,
  category: 'PANTAI' | 'KELUARGA' | 'DOKUMEN' | 'THUMBNAIL'
): ArrayBuffer {
  const canvas = document.createElement('canvas');
  canvas.width = width;
  canvas.height = height;
  const ctx = canvas.getContext('2d')!;

  // Gambar latar belakang pemandangan nyata
  if (category === 'PANTAI') {
    // Gradien senja langit pantai
    const sky = ctx.createLinearGradient(0, 0, 0, height * 0.65);
    sky.addColorStop(0, '#f97316');   // orange senja
    sky.addColorStop(0.4, '#fbbf24'); // kuning emas
    sky.addColorStop(1, '#0284c7');   // biru laut horizon
    ctx.fillStyle = sky;
    ctx.fillRect(0, 0, width, height * 0.65);

    // Matahari terbenam
    ctx.beginPath();
    ctx.arc(width * 0.5, height * 0.55, width * 0.12, 0, Math.PI * 2);
    ctx.fillStyle = '#fef08a';
    ctx.shadowColor = '#fbbf24';
    ctx.shadowBlur = 30;
    ctx.fill();
    ctx.shadowBlur = 0;

    // Air laut
    const sea = ctx.createLinearGradient(0, height * 0.65, 0, height);
    sea.addColorStop(0, '#0369a1');
    sea.addColorStop(1, '#0c4a6e');
    ctx.fillStyle = sea;
    ctx.fillRect(0, height * 0.65, width, height * 0.35);
  } else if (category === 'KELUARGA') {
    // Suasana taman hijau cerah
    const garden = ctx.createLinearGradient(0, 0, width, height);
    garden.addColorStop(0, '#065f46');
    garden.addColorStop(0.5, '#047857');
    garden.addColorStop(1, '#064e3b');
    ctx.fillStyle = garden;
    ctx.fillRect(0, 0, width, height);

    // Bunga & aksen warna
    ctx.fillStyle = '#f43f5e';
    ctx.beginPath();
    ctx.arc(width * 0.25, height * 0.7, width * 0.08, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = '#eab308';
    ctx.beginPath();
    ctx.arc(width * 0.75, height * 0.65, width * 0.09, 0, Math.PI * 2);
    ctx.fill();
  } else {
    // Mode Dokumen / Thumbnail
    const bg = ctx.createLinearGradient(0, 0, width, height);
    bg.addColorStop(0, '#1e293b');
    bg.addColorStop(1, '#0f172a');
    ctx.fillStyle = bg;
    ctx.fillRect(0, 0, width, height);
  }

  // Card info di atas foto
  ctx.fillStyle = 'rgba(15, 23, 42, 0.75)';
  ctx.roundRect ? ctx.roundRect(20, 20, width - 40, 90, 12) : ctx.fillRect(20, 20, width - 40, 90);
  ctx.fill();

  ctx.fillStyle = '#ffffff';
  ctx.font = 'bold 22px sans-serif';
  ctx.fillText(title, 36, 54);

  ctx.fillStyle = '#38bdf8';
  ctx.font = '14px monospace';
  ctx.fillText(`Dimensi: ${width}x${height} px | Pixel Verified: 100%`, 36, 82);

  const dataUrl = canvas.toDataURL('image/jpeg', 0.95);
  const byteString = atob(dataUrl.split(',')[1]);
  const ab = new ArrayBuffer(byteString.length);
  const ia = new Uint8Array(ab);
  for (let i = 0; i < byteString.length; i++) {
    ia[i] = byteString.charCodeAt(i);
  }
  return ab;
}

/**
 * Generator Video Nyata yang Terbukti Dapat Diputar dan Menampilkan Frame Bergerak
 */
export async function createRealPlayableVideoBlob(title: string): Promise<Blob> {
  return new Promise((resolve) => {
    try {
      const canvas = document.createElement('canvas');
      canvas.width = 480;
      canvas.height = 270;
      const ctx = canvas.getContext('2d')!;

      const stream = canvas.captureStream(25);
      let mimeType = 'video/webm;codecs=vp8';
      if (!MediaRecorder.isTypeSupported(mimeType)) {
        mimeType = 'video/webm';
      }

      const recorder = new MediaRecorder(stream, { mimeType });
      const chunks: Blob[] = [];

      recorder.ondataavailable = (e) => {
        if (e.data && e.data.size > 0) chunks.push(e.data);
      };

      recorder.onstop = () => {
        const videoBlob = new Blob(chunks, { type: 'video/webm' });
        resolve(videoBlob);
      };

      recorder.start();

      let frame = 0;
      const totalFrames = 50; // ~2 detik
      const interval = setInterval(() => {
        frame++;
        const t = frame / totalFrames;

        // Latar bergerak berwarna dinamis
        const bg = ctx.createLinearGradient(0, 0, 480, 270);
        bg.addColorStop(0, `rgb(${Math.round(20 + t * 40)}, ${Math.round(80 + t * 60)}, 160)`);
        bg.addColorStop(1, '#0284c7');
        ctx.fillStyle = bg;
        ctx.fillRect(0, 0, 480, 270);

        // Lingkaran bergerak (bukti frame bukan blank)
        ctx.fillStyle = '#f59e0b';
        ctx.beginPath();
        const posX = 60 + (480 - 120) * t;
        const posY = 135 + Math.sin(t * Math.PI * 4) * 40;
        ctx.arc(posX, posY, 28, 0, Math.PI * 2);
        ctx.fill();

        // Judul & Indikator
        ctx.fillStyle = '#ffffff';
        ctx.font = 'bold 18px sans-serif';
        ctx.fillText(title, 30, 45);

        ctx.fillStyle = '#bef264';
        ctx.font = 'bold 24px monospace';
        ctx.fillText(`Frame ${frame}/${totalFrames} [PLAYING]`, 30, 230);

        if (frame >= totalFrames) {
          clearInterval(interval);
          recorder.stop();
        }
      }, 40);
    } catch {
      resolve(new Blob([new Uint8Array([0x00])], { type: 'video/webm' }));
    }
  });
}

/**
 * Membuat data partisi Android nyata dengan uji decoder lengkap
 */
export async function createComprehensiveAndroidTestData(): Promise<{
  activeGalleryFiles: { name: string; path: string; buffer: ArrayBuffer }[];
  storageCandidates: {
    name: string;
    path: string;
    buffer: ArrayBuffer;
    prebuiltBlob?: Blob;
    tier: RecoveryTier;
    quality: QualityEstimate;
    isCorrupted: boolean;
    canPreview: boolean;
    canRecover: boolean;
    format: MediaFormat;
    type: 'image' | 'video';
    resolution?: string;
    duration?: string;
    unrecoverableReason?: string;
    decoderTested: boolean;
    decoderMessage: string;
  }[];
}> {
  // 1. Foto Aktif di Galeri (WAJIB DIFILTER KELUAR)
  const activeGalleryFiles = [
    {
      name: 'IMG_20240401_AKTIF_GALERI.JPG',
      path: 'DCIM/Camera/IMG_20240401_AKTIF_GALERI.JPG',
      buffer: createVibrantTestPhotoBuffer(1280, 720, 'FOTO AKTIF DI GALERI', 'DOKUMEN')
    }
  ];

  // 2. Video FULL_VALID yang nyata & terbukti dapat diputar
  const verifiedVideoBlob = await createRealPlayableVideoBlob('VID_20240501_PANTAI_SENJA');

  // 3. Foto FULL_VALID yang terbukti memiliki piksel
  const verifiedPhotoBuffer = createVibrantTestPhotoBuffer(1280, 720, 'FOTO ASLI PENUH: Sunset Pantai', 'PANTAI');

  // 4. File Header Saja / Korup (Header JPEG ada tapi payload blank / corrupt)
  const headerOnlyBuffer = new Uint8Array(2048);
  headerOnlyBuffer[0] = 0xFF;
  headerOnlyBuffer[1] = 0xD8;
  headerOnlyBuffer[2] = 0xFF;
  headerOnlyBuffer[3] = 0xE0; // JPEG SOI + APP0
  // Sisa byte dibiarkan nol (tidak ada SOF, tidak ada scanline, gagal decode)

  const storageCandidates = [
    // [FULL_VALID 1] Foto asli penuh yang terbukti terdekode
    {
      name: '.trashed-1714562700-SunsetPantai.jpg',
      path: 'Pictures/.trashed-1714562700-SunsetPantai.jpg',
      buffer: verifiedPhotoBuffer,
      prebuiltBlob: new Blob([verifiedPhotoBuffer], { type: 'image/jpeg' }),
      tier: 'FULL_VALID' as RecoveryTier,
      quality: 'Utuh (Data Asli Valid & Terdekode)' as QualityEstimate,
      isCorrupted: false,
      canPreview: true,
      canRecover: true,
      format: 'JPG' as MediaFormat,
      type: 'image' as const,
      resolution: '1280 x 720',
      decoderTested: true,
      decoderMessage: 'ImageDecoder sukses: 100% data raster piksel valid & terdekode.'
    },
    // [FULL_VALID 2] Video asli penuh yang terbukti dapat diputar
    {
      name: 'VID_20240501_SENJA_TRASHED.MP4',
      path: 'DCIM/Camera/.trashed-171829012.mp4',
      buffer: new ArrayBuffer(0),
      prebuiltBlob: verifiedVideoBlob,
      tier: 'FULL_VALID' as RecoveryTier,
      quality: 'Utuh (Data Asli Valid & Terdekode)' as QualityEstimate,
      isCorrupted: false,
      canPreview: true,
      canRecover: true,
      format: 'MP4' as MediaFormat,
      type: 'video' as const,
      resolution: '480 x 270',
      duration: '00:02',
      decoderTested: true,
      decoderMessage: 'VideoDecoder sukses: Demuxer berhasil membaca frame video aktif.'
    },
    // [THUMBNAIL_ONLY] Ekstraksi cache .thumbdata
    {
      name: 'THUMB_CACHE_DCIM_001.JPG',
      path: 'DCIM/.thumbnails/.thumbdata4--1967290299',
      buffer: createVibrantTestPhotoBuffer(256, 192, 'THUMBNAIL CACHE', 'THUMBNAIL'),
      prebuiltBlob: new Blob([createVibrantTestPhotoBuffer(256, 192, 'THUMBNAIL CACHE', 'THUMBNAIL')], { type: 'image/jpeg' }),
      tier: 'THUMBNAIL_ONLY' as RecoveryTier,
      quality: 'Thumbnail Saja (Resolusi Rendah)' as QualityEstimate,
      isCorrupted: false,
      canPreview: true,
      canRecover: true,
      format: 'JPG' as MediaFormat,
      type: 'image' as const,
      resolution: '256 x 192 (Cache)',
      decoderTested: true,
      decoderMessage: 'ImageDecoder sukses: Cache thumbnail sistem terverifikasi.'
    },
    // [HEADER_ONLY/CORRUPT] Signature ada tetapi payload gagal didekode
    {
      name: 'IMG_HEADER_ONLY_CORRUPTED.JPG',
      path: 'storage/emulated/0/LOST.DIR/Cluster_8492',
      buffer: headerOnlyBuffer.buffer,
      prebuiltBlob: new Blob([headerOnlyBuffer], { type: 'image/jpeg' }),
      tier: 'HEADER_ONLY/CORRUPT' as RecoveryTier,
      quality: 'Hanya Header / Data Korup' as QualityEstimate,
      isCorrupted: true,
      canPreview: false,
      canRecover: false,
      format: 'JPG' as MediaFormat,
      type: 'image' as const,
      unrecoverableReason: 'ImageDecoder gagal: Signature JPEG valid (FF D8 FF) tetapi payload tidak berisi data piksel yang dapat didekode.',
      decoderTested: true,
      decoderMessage: 'ImageDecoder Error: Payload scanline hancur / tidak ada data piksel.'
    },
    // [PARTIAL] Fragment foto terpotong
    {
      name: 'LOST_DIR_FRAGMENT_04918.JPG',
      path: 'LOST.DIR/LOST_DIR_FRAGMENT_04918.JPG',
      buffer: verifiedPhotoBuffer.slice(0, 18000),
      prebuiltBlob: new Blob([verifiedPhotoBuffer.slice(0, 18000)], { type: 'image/jpeg' }),
      tier: 'PARTIAL' as RecoveryTier,
      quality: 'Fragment Rusak / Sebagian' as QualityEstimate,
      isCorrupted: true,
      canPreview: true,
      canRecover: true,
      format: 'JPG' as MediaFormat,
      type: 'image' as const,
      resolution: '1280 x 720 (Terpotong)',
      decoderTested: true,
      decoderMessage: 'ImageDecoder sebagian: Terpotong di tengah stream (EOI hilang).'
    },
    // [METADATA_ONLY] Record MediaStore tanpa data fisik
    {
      name: 'IMG_20240315_METADATA_RECORD.JPG',
      path: 'MediaStore.Images / Row ID: 94812',
      buffer: new ArrayBuffer(0),
      tier: 'METADATA_ONLY' as RecoveryTier,
      quality: 'Hanya Metadata (Data Fisik Kosong)' as QualityEstimate,
      isCorrupted: true,
      canPreview: false,
      canRecover: false,
      format: 'JPG' as MediaFormat,
      type: 'image' as const,
      unrecoverableReason: 'Sektor fisik telah di-zero out oleh TRIM flash storage setelah trash dikosongkan. Hanya catatan nama & tanggal yang tersisa di MediaStore SQLite.',
      decoderTested: true,
      decoderMessage: 'Ukuran file 0 byte: Data fisik tidak ada.'
    }
  ];

  return { activeGalleryFiles, storageCandidates };
}
