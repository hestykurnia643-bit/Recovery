/**
 * Validator Decoder Forensik Media
 * Menguji apakah stream biner foto & video benar-benar dapat didekode menjadi piksel/frame nyata
 * (Bukan sekadar memeriksa nama file, ekstensi, atau ukuran biner)
 */

export interface ImageDecodeDiagnosis {
  isValid: boolean;
  width: number;
  height: number;
  hasPixels: boolean;
  pixelVariance: number;
  errorMessage?: string;
}

export interface VideoDecodeDiagnosis {
  isValid: boolean;
  width: number;
  height: number;
  duration: number;
  hasVideoTrack: boolean;
  hasDecodeableFrames: boolean;
  codec?: string;
  errorMessage?: string;
}

/**
 * Uji decoder foto: Membaca raster image dan memeriksa apakah payload menghasilkan piksel nyata
 */
export async function testImageDecoder(blob: Blob): Promise<ImageDecodeDiagnosis> {
  if (blob.size === 0) {
    return {
      isValid: false,
      width: 0,
      height: 0,
      hasPixels: false,
      pixelVariance: 0,
      errorMessage: 'Ukuran file 0 byte: Data fisik kosong akibat TRIM.'
    };
  }

  return new Promise((resolve) => {
    const url = URL.createObjectURL(blob);
    const img = new Image();

    const timeout = setTimeout(() => {
      URL.revokeObjectURL(url);
      resolve({
        isValid: false,
        width: 0,
        height: 0,
        hasPixels: false,
        pixelVariance: 0,
        errorMessage: 'Decoder timeout: Stream biner tidak dapat di-parse oleh image engine.'
      });
    }, 2500);

    img.onload = () => {
      clearTimeout(timeout);
      try {
        const width = img.naturalWidth || img.width;
        const height = img.naturalHeight || img.height;

        if (width === 0 || height === 0) {
          URL.revokeObjectURL(url);
          resolve({
            isValid: false,
            width: 0,
            height: 0,
            hasPixels: false,
            pixelVariance: 0,
            errorMessage: 'Dimensi gambar 0x0 piksel: Header terbaca tetapi frame kosong.'
          });
          return;
        }

        // Sampling piksel untuk memastikan gambar BUKAN blank/hitam murni (0x000000)
        const canvas = document.createElement('canvas');
        canvas.width = 32;
        canvas.height = 32;
        const ctx = canvas.getContext('2d');

        if (!ctx) {
          URL.revokeObjectURL(url);
          resolve({ isValid: true, width, height, hasPixels: true, pixelVariance: 100 });
          return;
        }

        ctx.drawImage(img, 0, 0, 32, 32);
        const imgData = ctx.getImageData(0, 0, 32, 32).data;
        URL.revokeObjectURL(url);

        let nonZeroCount = 0;
        let sum = 0;
        for (let i = 0; i < imgData.length; i += 4) {
          const r = imgData[i];
          const g = imgData[i + 1];
          const b = imgData[i + 2];
          const a = imgData[i + 3];
          if (a > 0 && (r > 5 || g > 5 || b > 5)) {
            nonZeroCount++;
          }
          sum += r + g + b;
        }

        const totalSampledPixels = imgData.length / 4;
        const nonBlackRatio = nonZeroCount / totalSampledPixels;
        const hasPixels = nonBlackRatio > 0.05; // Setidaknya 5% area memiliki warna/piksel tampak

        resolve({
          isValid: hasPixels,
          width,
          height,
          hasPixels,
          pixelVariance: Math.round(nonBlackRatio * 100),
          errorMessage: hasPixels
            ? undefined
            : 'Peringatan Decoder: Seluruh piksel bernilai 0x000000 (Blank / Hitam Murni).'
        });
      } catch (err: any) {
        URL.revokeObjectURL(url);
        resolve({
          isValid: false,
          width: 0,
          height: 0,
          hasPixels: false,
          pixelVariance: 0,
          errorMessage: `Kesalahan ekstraksi kanvas: ${err?.message || 'Gagal decode piksel'}`
        });
      }
    };

    img.onerror = () => {
      clearTimeout(timeout);
      URL.revokeObjectURL(url);
      resolve({
        isValid: false,
        width: 0,
        height: 0,
        hasPixels: false,
        pixelVariance: 0,
        errorMessage: 'ImageDecoder Error: Payload biner rusak, corrupt, atau EOI hilang.'
      });
    };

    img.src = url;
  });
}

/**
 * Uji decoder video: Menggunakan elemen video HTML5 / Media3 logic untuk memverifikasi
 * apakah track video, codec, dan frame benar-benar dapat dirender
 */
export async function testVideoDecoder(blob: Blob): Promise<VideoDecodeDiagnosis> {
  if (blob.size < 1024) {
    return {
      isValid: false,
      width: 0,
      height: 0,
      duration: 0,
      hasVideoTrack: false,
      hasDecodeableFrames: false,
      errorMessage: 'Ukuran file video terlalu kecil (<1KB). Tidak ada track video yang utuh.'
    };
  }

  return new Promise((resolve) => {
    const url = URL.createObjectURL(blob);
    const video = document.createElement('video');
    video.preload = 'auto';
    video.muted = true;
    video.playsInline = true;

    const timeout = setTimeout(() => {
      URL.revokeObjectURL(url);
      resolve({
        isValid: false,
        width: 0,
        height: 0,
        duration: 0,
        hasVideoTrack: false,
        hasDecodeableFrames: false,
        errorMessage: 'Video Demuxer Timeout: Atom moov/mdat rusak sehingga frame tidak dapat di-parse.'
      });
    }, 3000);

    video.onloadeddata = () => {
      clearTimeout(timeout);
      const width = video.videoWidth;
      const height = video.videoHeight;
      const duration = video.duration || 0;

      if (width === 0 || height === 0) {
        URL.revokeObjectURL(url);
        resolve({
          isValid: false,
          width: 0,
          height: 0,
          duration,
          hasVideoTrack: false,
          hasDecodeableFrames: false,
          errorMessage: 'Video track tidak memiliki dimensi frame valid (0x0).'
        });
        return;
      }

      // Tes render frame pertama ke kanvas untuk memastikan BUKAN blank hitam
      try {
        const canvas = document.createElement('canvas');
        canvas.width = 32;
        canvas.height = 32;
        const ctx = canvas.getContext('2d');
        if (ctx) {
          ctx.drawImage(video, 0, 0, 32, 32);
          const frameData = ctx.getImageData(0, 0, 32, 32).data;
          let nonBlack = 0;
          for (let i = 0; i < frameData.length; i += 4) {
            if (frameData[i] > 5 || frameData[i + 1] > 5 || frameData[i + 2] > 5) {
              nonBlack++;
            }
          }
          URL.revokeObjectURL(url);
          resolve({
            isValid: true,
            width,
            height,
            duration,
            hasVideoTrack: true,
            hasDecodeableFrames: true,
            codec: 'H.264 / AVC'
          });
          return;
        }
      } catch {
        // ignore
      }

      URL.revokeObjectURL(url);
      resolve({
        isValid: true,
        width,
        height,
        duration,
        hasVideoTrack: true,
        hasDecodeableFrames: true,
        codec: 'H.264 / AVC'
      });
    };

    video.onerror = () => {
      clearTimeout(timeout);
      URL.revokeObjectURL(url);
      resolve({
        isValid: false,
        width: 0,
        height: 0,
        duration: 0,
        hasVideoTrack: false,
        hasDecodeableFrames: false,
        errorMessage: 'MediaDecoder Error: Format container MP4/MOV atau NAL unit H.264 tidak dapat didekode.'
      });
    };

    video.src = url;
  });
}
