import React, { useState } from 'react';
import { X, Play, Download, ShieldCheck, AlertTriangle, HardDrive, Check, Film, Image as ImageIcon, ZoomIn, ZoomOut, Database, FileX, Info } from 'lucide-react';
import { RecoveredMediaItem } from '../types';

interface PreviewModalProps {
  item: RecoveredMediaItem | null;
  onClose: () => void;
  onToggleSelect: (id: string) => void;
  onRecoverSingle: (item: RecoveredMediaItem) => void;
}

export const PreviewModal: React.FC<PreviewModalProps> = ({
  item,
  onClose,
  onToggleSelect,
  onRecoverSingle
}) => {
  const [isZoomed, setIsZoomed] = useState(false);

  if (!item) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-slate-950/85 backdrop-blur-md animate-in fade-in duration-200">
      <div className="relative w-full max-w-4xl max-h-[92vh] bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl flex flex-col overflow-hidden">
        {/* Modal Header */}
        <div className="flex items-center justify-between px-5 py-3.5 border-b border-slate-800 bg-slate-900/90 shrink-0">
          <div className="flex items-center space-x-3 truncate">
            <div className="p-2 rounded-lg bg-slate-800 text-cyan-400">
              {item.type === 'video' ? <Film className="w-4 h-4" /> : <ImageIcon className="w-4 h-4" />}
            </div>
            <div className="truncate">
              <h3 className="text-sm font-bold text-white truncate" title={item.name}>
                {item.name}
              </h3>
              <p className="text-xs text-slate-400 flex items-center space-x-2">
                <span>{item.format} • {item.formattedSize}</span>
                <span>•</span>
                <span
                  className={
                    item.tier === 'FULL_VALID'
                      ? 'text-emerald-400 font-bold'
                      : item.tier === 'THUMBNAIL_ONLY'
                      ? 'text-blue-400 font-bold'
                      : item.tier === 'PARTIAL'
                      ? 'text-amber-400 font-bold'
                      : item.tier === 'HEADER_ONLY/CORRUPT'
                      ? 'text-orange-400 font-bold'
                      : 'text-slate-400 font-bold'
                  }
                >
                  {item.tier === 'FULL_VALID'
                    ? 'FULL_VALID (Terdekode)'
                    : item.tier === 'THUMBNAIL_ONLY'
                    ? 'THUMBNAIL ONLY'
                    : item.tier === 'PARTIAL'
                    ? 'PARTIAL (Fragment)'
                    : item.tier === 'HEADER_ONLY/CORRUPT'
                    ? 'HEADER_ONLY / KORUP'
                    : item.tier === 'METADATA_ONLY'
                    ? 'METADATA ONLY'
                    : 'UNRECOVERABLE'}
                </span>
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body: Media Preview + Forensics Drawer */}
        <div className="flex-1 overflow-y-auto grid grid-cols-1 lg:grid-cols-12 gap-0">
          {/* Main Visual Display (Left / Top: 7 cols) */}
          <div className="lg:col-span-7 bg-slate-950 flex flex-col items-center justify-center min-h-[300px] sm:min-h-[420px] p-4 relative border-b lg:border-b-0 lg:border-r border-slate-800">
            {item.tier === 'METADATA_ONLY' ? (
              <div className="w-full h-full flex flex-col items-center justify-center p-8 text-center space-y-3">
                <div className="w-16 h-16 rounded-2xl bg-slate-900 border border-slate-800 flex items-center justify-center text-slate-500">
                  <Database className="w-8 h-8 text-slate-400" />
                </div>
                <h4 className="text-base font-bold text-white">Data Fisik Tidak Tersedia (Hanya Metadata)</h4>
                <p className="text-xs text-slate-400 max-w-sm leading-relaxed">
                  Record file terdaftar di MediaStore Android, tetapi blok data fisik di NAND Flash telah dikosongkan (zeroed) oleh proses TRIM saat tong sampah dikosongkan.
                </p>
                <div className="px-3 py-1.5 rounded-lg bg-slate-900 border border-slate-800 text-[11px] text-amber-400 font-medium">
                  ⚠️ Sesuai standar forensik: Media ini tidak dapat dipreview atau dipulihkan.
                </div>
              </div>
            ) : item.tier === 'UNRECOVERABLE' ? (
              <div className="w-full h-full flex flex-col items-center justify-center p-8 text-center space-y-3">
                <div className="w-16 h-16 rounded-2xl bg-slate-900 border border-rose-900/60 flex items-center justify-center text-rose-500">
                  <FileX className="w-8 h-8" />
                </div>
                <h4 className="text-base font-bold text-white">Sektor Rusak / Tidak Dapat Dipulihkan</h4>
                <p className="text-xs text-slate-400 max-w-sm leading-relaxed">
                  {item.metadata.unrecoverableReason || 'Header dan cluster data telah tertimpa data baru.'}
                </p>
              </div>
            ) : item.type === 'video' ? (
              <div className="w-full h-full flex flex-col items-center justify-center">
                {item.videoUrl ? (
                  <div className="w-full flex flex-col items-center">
                    <video
                      src={item.videoUrl}
                      controls
                      autoPlay
                      playsInline
                      className="max-h-[380px] w-auto max-w-full rounded-lg shadow-xl border border-slate-800 bg-black"
                    >
                      Browser tidak mendukung pemutaran video ini.
                    </video>
                    <div className="mt-2 text-[11px] text-slate-400 font-mono flex items-center space-x-3">
                      <span>Format: {item.format}</span>
                      <span>•</span>
                      <span>Durasi: {item.metadata.duration || '00:03'}</span>
                      <span>•</span>
                      <span className="text-emerald-400 font-semibold">Video Valid & Dapat Diputar</span>
                    </div>
                  </div>
                ) : (
                  <div className="text-center p-6 space-y-2">
                    <AlertTriangle className="w-10 h-10 text-amber-400 mx-auto" />
                    <p className="text-xs text-slate-300">Container video terpotong dan tidak memiliki moov atom lengkap.</p>
                  </div>
                )}
              </div>
            ) : (
              <div className="relative w-full h-full flex items-center justify-center overflow-hidden">
                <img
                  src={item.previewUrl}
                  alt={item.name}
                  className={`max-h-[380px] sm:max-h-[420px] w-auto max-w-full object-contain rounded-lg transition-transform duration-300 ${
                    isZoomed ? 'scale-150 cursor-zoom-out' : 'cursor-zoom-in'
                  }`}
                  onClick={() => setIsZoomed(!isZoomed)}
                />

                {/* Zoom toggle button */}
                <button
                  onClick={() => setIsZoomed(!isZoomed)}
                  className="absolute bottom-3 right-3 p-2 rounded-lg bg-slate-900/80 backdrop-blur-sm border border-slate-700 text-slate-300 hover:text-white"
                  title={isZoomed ? 'Zoom Out' : 'Zoom In'}
                >
                  {isZoomed ? <ZoomOut className="w-4 h-4" /> : <ZoomIn className="w-4 h-4" />}
                </button>
              </div>
            )}

            {/* Special Notification Banners */}
            {item.tier === 'THUMBNAIL_ONLY' && (
              <div className="absolute top-3 left-3 right-3 p-2.5 rounded-lg bg-blue-950/90 border border-blue-700/80 backdrop-blur-md flex items-start space-x-2 text-xs text-blue-200">
                <Info className="w-4 h-4 text-blue-400 shrink-0 mt-0.5" />
                <div>
                  <span className="font-bold text-blue-300">Status: THUMBNAIL ONLY.</span> Ini adalah pratinjau cache resolusi rendah yang disimpan sistem Android, <em>bukan</em> file foto asli resolusi penuh.
                </div>
              </div>
            )}

            {item.tier === 'PARTIAL' && (
              <div className="absolute top-3 left-3 right-3 p-2.5 rounded-lg bg-amber-950/90 border border-amber-700/80 backdrop-blur-md flex items-start space-x-2 text-xs text-amber-200">
                <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                <div>
                  <span className="font-bold text-amber-300">Status: PARTIAL (Fragment Sebagian).</span> Sebagian stream berhasil diekstrak sebelum sektor fisik terpotong. Tetap dapat dipreview sebagian.
                </div>
              </div>
            )}

            {item.tier === 'FULL_VALID' && (
              <div className="absolute top-3 left-3 right-3 p-2 rounded-lg bg-emerald-950/80 border border-emerald-700/80 backdrop-blur-md flex items-center space-x-2 text-xs text-emerald-200">
                <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0" />
                <div>
                  <span className="font-bold text-emerald-300">Status: FULL_VALID.</span> Data media asli ditemukan utuh, valid, dan terbukti terdekode dengan piksel/frame aktif.
                </div>
              </div>
            )}

            {item.tier === 'HEADER_ONLY/CORRUPT' && (
              <div className="absolute top-3 left-3 right-3 p-2.5 rounded-lg bg-orange-950/90 border border-orange-700/80 backdrop-blur-md flex items-start space-x-2 text-xs text-orange-200">
                <AlertTriangle className="w-4 h-4 text-orange-400 shrink-0 mt-0.5" />
                <div>
                  <span className="font-bold text-orange-300">Status: HEADER_ONLY / KORUP.</span> Struktur awal/header ada tetapi payload rusak/kosong sehingga gagal didekode menjadi piksel.
                </div>
              </div>
            )}
          </div>

          {/* Forensics Technical Metadata (Right / Bottom: 5 cols) */}
          <div className="lg:col-span-5 p-5 bg-slate-900 flex flex-col justify-between space-y-4">
            <div className="space-y-4">
              <div>
                <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-2 flex items-center space-x-1.5">
                  <HardDrive className="w-3.5 h-3.5 text-cyan-400" />
                  <span>Detail Forensik Android</span>
                </h4>

                {/* Integrity Progress Bar */}
                <div className="bg-slate-950 p-3 rounded-xl border border-slate-800 space-y-1.5">
                  <div className="flex justify-between text-xs">
                    <span className="text-slate-400 font-medium">Integritas File</span>
                    <span
                      className={`font-bold ${
                        item.integrityScore >= 90
                          ? 'text-emerald-400'
                          : item.integrityScore >= 50
                          ? 'text-amber-400'
                          : 'text-rose-400'
                      }`}
                    >
                      {item.integrityScore}%
                    </span>
                  </div>
                  <div className="w-full h-2 bg-slate-900 rounded-full overflow-hidden">
                    <div
                      className={`h-full rounded-full ${
                        item.integrityScore >= 90
                          ? 'bg-emerald-500'
                          : item.integrityScore >= 50
                          ? 'bg-amber-500'
                          : 'bg-rose-500'
                      }`}
                      style={{ width: `${item.integrityScore}%` }}
                    />
                  </div>
                </div>
              </div>

              {/* Technical Property List */}
              <div className="space-y-2 text-xs">
                <div className="p-2.5 rounded-lg bg-slate-950/60 border border-slate-800/80 flex flex-col space-y-0.5">
                  <span className="text-[10px] text-slate-500 uppercase tracking-wider">Lokasi / Sumber Jejak</span>
                  <span className="font-mono text-cyan-300 break-all">{item.sourceDescription}</span>
                </div>

                <div className="grid grid-cols-2 gap-2">
                  <div className="p-2 rounded-lg bg-slate-950/60 border border-slate-800/80">
                    <span className="text-[10px] text-slate-500 uppercase tracking-wider block">Resolusi</span>
                    <span className="font-semibold text-slate-200">{item.metadata.resolution || '-'}</span>
                  </div>
                  <div className="p-2 rounded-lg bg-slate-950/60 border border-slate-800/80">
                    <span className="text-[10px] text-slate-500 uppercase tracking-wider block">Ukuran File</span>
                    <span className="font-semibold text-slate-200">{item.formattedSize}</span>
                  </div>
                </div>

                {item.metadata.duration && (
                  <div className="p-2 rounded-lg bg-slate-950/60 border border-slate-800/80">
                    <span className="text-[10px] text-slate-500 uppercase tracking-wider block">Durasi Video</span>
                    <span className="text-emerald-400 font-mono font-semibold">{item.metadata.duration}</span>
                  </div>
                )}

                {item.metadata.magicHeader && (
                  <div className="p-2 rounded-lg bg-slate-950/60 border border-slate-800/80">
                    <span className="text-[10px] text-slate-500 uppercase tracking-wider block">Magic Byte Header</span>
                    <span className="font-mono text-[11px] text-teal-400">{item.metadata.magicHeader}</span>
                  </div>
                )}

                {item.metadata.decoderMessage && (
                  <div className="p-2.5 rounded-lg bg-slate-950/80 border border-slate-800 space-y-1">
                    <span className="text-[10px] text-cyan-400 uppercase tracking-wider font-semibold block">Hasil Uji Decoder Nyata</span>
                    <span className="text-slate-300 font-mono text-[11px] block">{item.metadata.decoderMessage}</span>
                  </div>
                )}

                {item.metadata.unrecoverableReason && (
                  <div className="p-2.5 rounded-lg bg-rose-950/40 border border-rose-900/60 space-y-1">
                    <span className="text-[10px] text-rose-400 uppercase tracking-wider font-semibold block">Diagnostik Kegagalan</span>
                    <span className="text-rose-200 text-[11px] block">{item.metadata.unrecoverableReason}</span>
                  </div>
                )}

                <div className="p-2 rounded-lg bg-slate-950/60 border border-slate-800/80">
                  <span className="text-[10px] text-slate-500 uppercase tracking-wider block">Klasifikasi Pemulihan</span>
                  <span className="font-bold text-white">{item.quality}</span>
                </div>
              </div>
            </div>

            {/* Modal Actions */}
            <div className="pt-3 border-t border-slate-800 space-y-2">
              {item.canRecover ? (
                <>
                  <button
                    onClick={() => onRecoverSingle(item)}
                    className="w-full py-2.5 px-4 rounded-xl bg-gradient-to-r from-cyan-500 to-teal-500 hover:from-cyan-400 hover:to-teal-400 text-slate-950 font-bold text-xs flex items-center justify-center space-x-2 shadow-lg shadow-cyan-500/20 active:scale-[0.99] transition-all cursor-pointer"
                  >
                    <Download className="w-4 h-4" />
                    <span>Pulihkan File Ini Sekarang</span>
                  </button>

                  <button
                    onClick={() => onToggleSelect(item.id)}
                    className={`w-full py-2 px-4 rounded-xl border text-xs font-semibold flex items-center justify-center space-x-2 transition-all cursor-pointer ${
                      item.selected
                        ? 'bg-cyan-950/70 border-cyan-500 text-cyan-300'
                        : 'bg-slate-800 hover:bg-slate-700 border-slate-700 text-slate-300'
                    }`}
                  >
                    <Check className={`w-3.5 h-3.5 ${item.selected ? 'text-cyan-400' : 'opacity-0'}`} />
                    <span>{item.selected ? 'Telah Dipilih (Keluarkan)' : 'Pilih File Ini'}</span>
                  </button>
                </>
              ) : (
                <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 text-center text-xs text-slate-400">
                  ❌ File ini tidak dapat dipulihkan karena tidak ada data biner fisik yang tersisa.
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
