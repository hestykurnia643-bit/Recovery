import React from 'react';
import { X, ShieldCheck, AlertTriangle, Cpu, HardDrive, Database, Info, CheckCircle2 } from 'lucide-react';

interface TechnicalInfoModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const TechnicalInfoModal: React.FC<TechnicalInfoModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-slate-950/85 backdrop-blur-md animate-in fade-in duration-200">
      <div className="relative w-full max-w-2xl max-h-[90vh] bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl flex flex-col overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between p-5 border-b border-slate-800 bg-slate-900/90 shrink-0">
          <div className="flex items-center space-x-2.5">
            <div className="p-2 rounded-xl bg-cyan-950 border border-cyan-800 text-cyan-400">
              <Info className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-white">Transparansi Teknis & Keterbatasan Non-Root</h3>
              <p className="text-xs text-slate-400">Prinsip kerja forensik penyimpanan Android tanpa izin ROOT</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Content */}
        <div className="p-5 overflow-y-auto space-y-4 text-xs text-slate-300 leading-relaxed">
          {/* Section 1: Keterbatasan Fisik NAND Flash */}
          <div className="p-3.5 rounded-xl bg-amber-950/30 border border-amber-800/50 space-y-1.5">
            <div className="flex items-center space-x-2 text-amber-300 font-bold text-sm">
              <AlertTriangle className="w-4 h-4 shrink-0" />
              <span>Keterbatasan Fisik: Mengapa Tidak Pernah Ada Klaim 100%?</span>
            </div>
            <p className="text-slate-300">
              Pada smartphone Android modern (UFS / eMMC Flash), ketika sebuah file dihapus dari tong sampah dan sistem menjalankan perintah <strong>TRIM / Flash Garbage Collection</strong>, sel semikonduktor fisik akan dikosongkan (zero-out) untuk efisiensi keausan chip. Aplikasi recovery yang mengklaim &quot;Pasti 100% Kembali&quot; adalah <strong>klaim palsu</strong>.
            </p>
          </div>

          {/* Section 2: Bagaimana Photo Recovery Bekerja Tanpa Root */}
          <div className="space-y-3">
            <h4 className="text-sm font-bold text-white flex items-center space-x-2">
              <Cpu className="w-4 h-4 text-cyan-400" />
              <span>3 Jalur Pemulihan Maksimal yang Diizinkan Android:</span>
            </h4>

            <div className="space-y-2">
              <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 space-y-1">
                <span className="font-semibold text-cyan-300 block">
                  1. Deep Carving Database Thumbnail (.thumbdata)
                </span>
                <p className="text-slate-400">
                  Ketika foto dihapus dari Gallery dan Trash, sistem Android sering kali <em>tidak</em> menghapus thumbnail resolusi tinggi yang tersimpan dalam file biner terkompilasi seperti <code className="text-slate-200">DCIM/.thumbnails/.thumbdata4--*</code>. Mesin kami membedah struktur byte untuk mengekstrak foto berdefinisi tinggi utuh.
                </p>
              </div>

              <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 space-y-1">
                <span className="font-semibold text-cyan-300 block">
                  2. Residue System Trash & Pending MediaStore Inodes
                </span>
                <p className="text-slate-400">
                  Melalui query <code className="text-slate-200">MediaStore.QUERY_ARG_MATCH_TRASHED</code> dan partisi cache bersama, kami mendeteksi file yang masih berada di sektor penyimpanan fisik tetapi tanda visibilitasnya di galeri telah dinonaktifkan oleh sistem operasi.
                </p>
              </div>

              <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 space-y-1">
                <span className="font-semibold text-cyan-300 block">
                  3. Cache Aplikasi Pesan (WhatsApp, Telegram) & LOST.DIR
                </span>
                <p className="text-slate-400">
                  Banyak foto yang terhapus dari kamera utama sebenarnya masih meninggalkan salinan cache di direktori media pesan atau sektor yatim (<code className="text-slate-200">LOST.DIR</code>) yang diidentifikasi melalui Magic Byte header (JPEG SOI <code className="text-slate-200">FF D8 FF</code>, PNG <code className="text-slate-200">89 50 4E 47</code>, MP4 <code className="text-slate-200">ftyp</code>).
                </p>
              </div>
            </div>
          </div>

          {/* Section 3: Mengapa Galeri Aktif Diabaikan */}
          <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 space-y-1.5">
            <div className="flex items-center space-x-2 text-emerald-400 font-bold">
              <ShieldCheck className="w-4 h-4" />
              <span>Bukan Gallery Viewer (Pengecualian Media Aktif)</span>
            </div>
            <p className="text-slate-400">
              Aplikasi ini <strong>bukan sekadar penampil galeri</strong>. Sebelum scan dimulai, sistem mengindeks seluruh file yang masih normal dan aktif di memori HP Anda untuk dijadikan daftar pengecualian. Hanya jejak media yang benar-benar telah hilang dari galeri yang ditampilkan ke daftar pemulihan.
            </p>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-slate-800 bg-slate-900/90 flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-semibold text-xs transition-colors"
          >
            Mengerti & Tutup
          </button>
        </div>
      </div>
    </div>
  );
};
