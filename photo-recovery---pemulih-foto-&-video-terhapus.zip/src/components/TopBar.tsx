import React from 'react';
import { ShieldCheck, Code, Info, HardDrive } from 'lucide-react';

interface TopBarProps {
  onOpenSourceModal: () => void;
  onOpenInfoModal: () => void;
}

export const TopBar: React.FC<TopBarProps> = ({ onOpenSourceModal, onOpenInfoModal }) => {
  return (
    <header className="sticky top-0 z-30 bg-slate-900/90 backdrop-blur-md border-b border-slate-800 px-4 py-3 sm:px-6">
      <div className="max-w-7xl mx-auto flex items-center justify-between">
        {/* App Title & Identity */}
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-cyan-600 via-cyan-500 to-teal-400 p-0.5 shadow-lg shadow-cyan-500/20 flex items-center justify-center">
            <div className="w-full h-full bg-slate-950 rounded-[10px] flex items-center justify-center">
              <HardDrive className="w-5 h-5 text-cyan-400 animate-pulse" />
            </div>
          </div>
          <div>
            <div className="flex items-center space-x-2">
              <h1 className="text-lg font-bold tracking-tight text-white flex items-center">
                Photo Recovery
              </h1>
              <span className="text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded-full bg-cyan-950 text-cyan-400 border border-cyan-800/60 hidden sm:inline-flex">
                Android Native SAF
              </span>
            </div>
            <p className="text-xs text-slate-400">
              Pemulih Foto & Video Terhapus dari Trash HP (Non-Root)
            </p>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex items-center space-x-2">
          {/* Security Badge */}
          <div className="hidden md:flex items-center space-x-1.5 px-2.5 py-1 rounded-lg bg-emerald-950/60 border border-emerald-800/40 text-emerald-400 text-xs">
            <ShieldCheck className="w-3.5 h-3.5" />
            <span className="font-medium">Resmi & Tanpa Root</span>
          </div>

          {/* Android Source Code Button */}
          <button
            onClick={onOpenSourceModal}
            className="flex items-center space-x-1.5 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-xs font-medium transition-all shadow-sm hover:border-cyan-500/50"
            title="Lihat Source Code Android Studio (Kotlin)"
          >
            <Code className="w-3.5 h-3.5 text-cyan-400" />
            <span className="hidden sm:inline">Source Android (APK)</span>
            <span className="sm:hidden">APK Code</span>
          </button>

          {/* Info & Forensics Modal Button */}
          <button
            onClick={onOpenInfoModal}
            className="p-1.5 sm:px-3 sm:py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 text-xs font-medium transition-all flex items-center space-x-1.5"
            title="Penjelasan Keterbatasan Teknis & Forensik"
          >
            <Info className="w-4 h-4 text-slate-400" />
            <span className="hidden sm:inline">Info & Keterbatasan</span>
          </button>
        </div>
      </div>
    </header>
  );
};
