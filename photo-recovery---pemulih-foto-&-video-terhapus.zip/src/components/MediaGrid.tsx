import React from 'react';
import { Play, Check, AlertTriangle, Eye, ShieldCheck, Film, Image as ImageIcon, Database, FileX } from 'lucide-react';
import { RecoveredMediaItem } from '../types';

interface MediaGridProps {
  items: RecoveredMediaItem[];
  onToggleSelect: (id: string, e?: React.MouseEvent) => void;
  onPreview: (item: RecoveredMediaItem) => void;
  hasScanned?: boolean;
  skippedActiveCount?: number;
}

export const MediaGrid: React.FC<MediaGridProps> = ({
  items,
  onToggleSelect,
  onPreview,
  hasScanned = false,
  skippedActiveCount = 0
}) => {
  if (items.length === 0) {
    return (
      <div className="bg-slate-900/40 border border-slate-800/80 rounded-2xl p-10 sm:p-14 text-center">
        <div className="w-16 h-16 mx-auto rounded-2xl bg-slate-800/80 flex items-center justify-center text-slate-500 mb-4">
          <ImageIcon className="w-8 h-8 text-cyan-400" />
        </div>
        {hasScanned ? (
          <div className="max-w-md mx-auto space-y-2">
            <h3 className="text-base font-bold text-white">
              Tidak Ada Jejak Media Terhapus Ditemukan
            </h3>
            <p className="text-xs text-slate-400 leading-relaxed">
              {skippedActiveCount > 0 ? (
                <>
                  <strong className="text-slate-200">{skippedActiveCount} foto aktif di Galeri</strong> berhasil difilter dan tidak dimasukkan ke hasil recovery. Sektor jejak sampah lainnya telah dikosongkan permanen oleh proses TRIM Android.
                </>
              ) : (
                'Tidak ditemukan jejak file biner thumbnail (.thumbdata), cache tersembunyi, atau file trashed pada lokasi ini.'
              )}
            </p>
            <div className="p-3 mt-3 rounded-xl bg-slate-950/80 border border-slate-800 text-[11px] text-slate-400">
              🛡️ Sesuai standar forensik resmi: Sistem tidak akan menampilkan hasil palsu jika data memang sudah tidak bersisa.
            </div>
          </div>
        ) : (
          <div className="max-w-md mx-auto space-y-1">
            <h3 className="text-base font-bold text-white">Belum Ada Pemindaian Berjalan</h3>
            <p className="text-xs text-slate-400">
              Klik tombol <span className="text-cyan-400 font-medium">"Mulai Deep Scan"</span> untuk memindai database thumbnail, cluster jejak sampah, dan fragment storage.
            </p>
          </div>
        )}
      </div>
    );
  }

  return (
    <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-3 sm:gap-4">
      {items.map((item) => {
        return (
          <div
            key={item.id}
            onClick={() => onPreview(item)}
            className={`group relative rounded-xl overflow-hidden border transition-all duration-200 cursor-pointer flex flex-col bg-slate-900/90 ${
              item.selected
                ? 'border-cyan-400 ring-2 ring-cyan-400/30 shadow-lg shadow-cyan-950/50'
                : 'border-slate-800 hover:border-slate-700 hover:shadow-md'
            }`}
          >
            {/* Media Box Display */}
            <div className="relative aspect-square w-full bg-slate-950 overflow-hidden flex items-center justify-center">
              {item.tier === 'METADATA_ONLY' ? (
                <div className="w-full h-full flex flex-col items-center justify-center p-3 text-center bg-slate-950/90 border-b border-slate-800/80">
                  <Database className="w-8 h-8 text-slate-500 mb-1.5" />
                  <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">
                    Hanya Metadata
                  </span>
                  <span className="text-[9px] text-slate-500 mt-0.5 leading-tight">
                    Data fisik kosong (TRIM)
                  </span>
                </div>
              ) : item.tier === 'UNRECOVERABLE' ? (
                <div className="w-full h-full flex flex-col items-center justify-center p-3 text-center bg-slate-950/90 border-b border-slate-800/80">
                  <FileX className="w-8 h-8 text-rose-500/70 mb-1.5" />
                  <span className="text-[10px] font-bold text-rose-400 uppercase tracking-wider">
                    Unrecoverable
                  </span>
                  <span className="text-[9px] text-slate-500 mt-0.5 leading-tight">
                    Sektor rusak / tertimpa
                  </span>
                </div>
              ) : (
                <>
                  <img
                    src={item.previewUrl}
                    alt={item.name}
                    loading="lazy"
                    className={`w-full h-full object-cover transition-transform duration-300 group-hover:scale-105 ${
                      item.isCorrupted ? 'opacity-85 filter contrast-125' : ''
                    }`}
                  />

                  {/* Corrupted Scanline Overlay if marked corrupted */}
                  {item.isCorrupted && (
                    <div className="absolute inset-0 bg-gradient-to-b from-transparent via-amber-500/10 to-transparent pointer-events-none opacity-50" />
                  )}

                  {/* Video Play Indicator */}
                  {item.type === 'video' && item.canPreview && (
                    <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                      <div className="w-10 h-10 rounded-full bg-slate-950/80 backdrop-blur-sm border border-cyan-400/40 flex items-center justify-center shadow-lg group-hover:scale-110 transition-transform">
                        <Play className="w-4 h-4 text-cyan-300 fill-cyan-300 ml-0.5" />
                      </div>
                    </div>
                  )}
                </>
              )}

              {/* Format Badge (Top Left) */}
              <div className="absolute top-2 left-2 z-10">
                <span className="px-1.5 py-0.5 rounded text-[10px] font-mono font-bold bg-slate-950/80 backdrop-blur-sm border border-slate-700/60 text-cyan-300 shadow">
                  {item.format}
                </span>
              </div>

              {/* Select Checkbox (Top Right) - Only for recoverable items */}
              {item.canRecover && (
                <div
                  className="absolute top-2 right-2 z-10"
                  onClick={(e) => {
                    e.stopPropagation();
                    onToggleSelect(item.id, e);
                  }}
                >
                  <button
                    type="button"
                    aria-label={item.selected ? 'Batalkan pilihan' : 'Pilih file'}
                    className={`w-6 h-6 rounded-md flex items-center justify-center transition-all ${
                      item.selected
                        ? 'bg-cyan-500 text-slate-950 font-bold shadow-md'
                        : 'bg-slate-950/70 border border-slate-600/80 text-transparent hover:border-cyan-400'
                    }`}
                  >
                    <Check className={`w-3.5 h-3.5 stroke-[3] ${item.selected ? 'text-slate-950' : 'opacity-0'}`} />
                  </button>
                </div>
              )}

              {/* Video Duration / Image Dimensions (Bottom Left) */}
              <div className="absolute bottom-2 left-2 z-10">
                <span className="px-1.5 py-0.5 rounded text-[9px] font-mono bg-slate-950/85 text-slate-300 border border-slate-800">
                  {item.type === 'video'
                    ? item.metadata.duration || 'Video'
                    : item.metadata.resolution?.split(' ')[0] || item.formattedSize}
                </span>
              </div>

              {/* Explicit Tier Badge (Bottom Right) */}
              <div className="absolute bottom-2 right-2 z-10">
                {item.tier === 'FULL_VALID' ? (
                  <span
                    className="flex items-center space-x-0.5 px-1.5 py-0.5 rounded text-[9px] font-bold bg-emerald-950/90 text-emerald-300 border border-emerald-600 shadow"
                    title="Data Asli Valid & Terdekode"
                  >
                    <ShieldCheck className="w-2.5 h-2.5" />
                    <span>FULL VALID</span>
                  </span>
                ) : item.tier === 'PARTIAL' ? (
                  <span
                    className="flex items-center space-x-0.5 px-1.5 py-0.5 rounded text-[9px] font-bold bg-amber-950/90 text-amber-300 border border-amber-600 shadow"
                    title="Fragment Sebagian"
                  >
                    <AlertTriangle className="w-2.5 h-2.5" />
                    <span>PARTIAL</span>
                  </span>
                ) : item.tier === 'HEADER_ONLY/CORRUPT' ? (
                  <span
                    className="flex items-center space-x-0.5 px-1.5 py-0.5 rounded text-[9px] font-bold bg-orange-950/90 text-orange-300 border border-orange-600 shadow"
                    title="Header Saja / Gagal Decode"
                  >
                    <AlertTriangle className="w-2.5 h-2.5" />
                    <span>HEADER ONLY</span>
                  </span>
                ) : item.tier === 'THUMBNAIL_ONLY' ? (
                  <span
                    className="px-1.5 py-0.5 rounded text-[9px] font-bold bg-blue-950/90 text-blue-300 border border-blue-600 shadow"
                    title="Thumbnail Cache (Bukan Foto Asli)"
                  >
                    THUMB ONLY
                  </span>
                ) : item.tier === 'METADATA_ONLY' ? (
                  <span
                    className="px-1.5 py-0.5 rounded text-[9px] font-bold bg-slate-800 text-slate-400 border border-slate-600 shadow"
                    title="Hanya Metadata - Fisik Kosong"
                  >
                    METADATA
                  </span>
                ) : (
                  <span
                    className="px-1.5 py-0.5 rounded text-[9px] font-bold bg-rose-950/90 text-rose-300 border border-rose-800 shadow"
                    title="Sektor Rusak"
                  >
                    UNRECOVERABLE
                  </span>
                )}
              </div>

              {/* Quick Preview Hover Overlay */}
              <div className="absolute inset-0 bg-slate-950/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center pointer-events-none">
                <div className="px-2.5 py-1 rounded-full bg-slate-900/90 border border-slate-700 text-white text-[11px] font-medium flex items-center space-x-1 shadow-lg">
                  <Eye className="w-3 h-3 text-cyan-400" />
                  <span>Lihat Detail</span>
                </div>
              </div>
            </div>

            {/* Info Footer */}
            <div className="p-2 sm:p-2.5 flex flex-col justify-between flex-1 space-y-1">
              <div className="truncate text-xs font-semibold text-slate-200 group-hover:text-cyan-300 transition-colors" title={item.name}>
                {item.name}
              </div>

              <div className="flex items-center justify-between text-[11px] text-slate-400">
                <span className="font-mono text-slate-300">{item.formattedSize}</span>
                <span className="text-[10px] text-slate-500 truncate max-w-[65%]" title={item.sourceDescription}>
                  {item.sourceType === 'thumbnail_cache'
                    ? '.thumbdata'
                    : item.sourceType === 'trash_residual'
                    ? 'Trash Inode'
                    : item.sourceType === 'mediastore_orphan'
                    ? 'MediaStore DB'
                    : item.sourceType === 'app_cache'
                    ? 'App Cache'
                    : 'LOST.DIR'}
                </span>
              </div>

              {/* Status if already recovered */}
              {item.recovered && (
                <div className="mt-1 pt-1 border-t border-slate-800 flex items-center justify-between text-[10px] text-emerald-400 font-medium">
                  <span className="flex items-center space-x-1">
                    <Check className="w-3 h-3" />
                    <span>Telah Dipulihkan</span>
                  </span>
                </div>
              )}
            </div>
          </div>
        );
      })}
    </div>
  );
};
