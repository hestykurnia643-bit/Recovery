import React, { useState } from 'react';
import { X, Code, Download, FileCode, Check, Copy, Terminal, ExternalLink, ShieldCheck } from 'lucide-react';
import JSZip from 'jszip';
import { ANDROID_SOURCE_FILES } from '../services/nativeAndroidSources';
import { AndroidSourceFile } from '../types';

interface AndroidProjectModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const AndroidProjectModal: React.FC<AndroidProjectModalProps> = ({ isOpen, onClose }) => {
  const [selectedFile, setSelectedFile] = useState<AndroidSourceFile>(ANDROID_SOURCE_FILES[2]); // DeepScanEngine.kt by default
  const [copied, setCopied] = useState(false);
  const [isZipping, setIsZipping] = useState(false);

  if (!isOpen) return null;

  const handleCopyCode = () => {
    navigator.clipboard.writeText(selectedFile.content);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownloadZip = async () => {
    setIsZipping(true);
    try {
      const zip = new JSZip();

      // Folder structure
      const rootFolder = zip.folder('PhotoRecovery-Android-Project');

      // Add each source file
      ANDROID_SOURCE_FILES.forEach((file) => {
        rootFolder?.file(file.path, file.content);
      });

      // Add gradle wrapper properties and settings
      rootFolder?.file(
        'settings.gradle.kts',
        `pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
    }
}
rootProject.name = "PhotoRecovery"
include(":app")
`
      );

      rootFolder?.file(
        'build.gradle.kts',
        `// Top-level build file where you can add configuration options common to all sub-projects/modules.
plugins {
    alias(libs.plugins.android.application) apply false
    alias(libs.plugins.kotlin.android) apply false
    alias(libs.plugins.kotlin.compose) apply false
}
`
      );

      rootFolder?.file(
        'gradle/libs.versions.toml',
        `[versions]
agp = "8.3.1"
kotlin = "1.9.22"
composeBom = "2024.04.00"

[libraries]
androidx-core-ktx = { group = "androidx.core", name = "core-ktx", version = "1.12.0" }
androidx-lifecycle-runtime-ktx = { group = "androidx.lifecycle", name = "lifecycle-runtime-ktx", version = "2.7.0" }
androidx-activity-compose = { group = "androidx.activity", name = "activity-compose", version = "1.8.2" }
androidx-compose-bom = { group = "androidx.compose", name = "compose-bom", version.ref = "composeBom" }
androidx-compose-ui = { group = "androidx.compose.ui", name = "ui" }
androidx-compose-ui-graphics = { group = "androidx.compose.ui", name = "ui-graphics" }
androidx-compose-ui-tooling-preview = { group = "androidx.compose.ui", name = "ui-tooling-preview" }
androidx-compose-material3 = { group = "androidx.compose.material3", name = "material3" }
androidx-compose-material-icons-extended = { group = "androidx.compose.material", name = "material-icons-extended" }

[plugins]
android-application = { id = "com.android.application", version.ref = "agp" }
kotlin-android = { id = "org.jetbrains.kotlin.android", version.ref = "kotlin" }
kotlin-compose = { id = "org.jetbrains.kotlin.plugin.compose", version.ref = "kotlin" }
`
      );

      const blob = await zip.generateAsync({ type: 'blob' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'PhotoRecovery-Android-Kotlin-Source.zip';
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    } catch (err) {
      console.error('Failed to create ZIP', err);
    } finally {
      setIsZipping(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-slate-950/85 backdrop-blur-md animate-in fade-in duration-200">
      <div className="relative w-full max-w-5xl h-[90vh] bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl flex flex-col overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-slate-800 bg-slate-900/90 shrink-0">
          <div className="flex items-center space-x-3">
            <div className="p-2 rounded-xl bg-cyan-950 border border-cyan-800 text-cyan-400">
              <Code className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <h3 className="text-base font-bold text-white">Source Code Project Android Native (Kotlin)</h3>
                <span className="text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded-full bg-emerald-950 text-emerald-400 border border-emerald-800">
                  Ready to Build APK
                </span>
              </div>
              <p className="text-xs text-slate-400">
                Arsitektur resmi Android SDK 34 • Jetpack Compose • SAF Storage Access • Tanpa Root
              </p>
            </div>
          </div>

          <div className="flex items-center space-x-2">
            <button
              onClick={handleDownloadZip}
              disabled={isZipping}
              className="px-3.5 py-2 rounded-xl bg-gradient-to-r from-cyan-500 to-teal-500 hover:from-cyan-400 hover:to-teal-400 text-slate-950 font-bold text-xs flex items-center space-x-2 shadow-lg shadow-cyan-500/20 transition-all cursor-pointer"
            >
              <Download className="w-4 h-4" />
              <span>{isZipping ? 'Mengompres ZIP...' : 'Download Project (.ZIP)'}</span>
            </button>

            <button
              onClick={onClose}
              className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Modal Body: File tree on left, Code editor on right */}
        <div className="flex-1 grid grid-cols-1 md:grid-cols-12 min-h-0 overflow-hidden">
          {/* File Tree (Left 4 cols) */}
          <div className="md:col-span-4 bg-slate-950/70 border-r border-slate-800 p-3 overflow-y-auto flex flex-col space-y-1">
            <div className="text-[11px] font-bold uppercase tracking-wider text-slate-500 px-2 py-1 flex items-center justify-between">
              <span>File Sumber Daya Android</span>
              <span className="font-mono text-cyan-400">{ANDROID_SOURCE_FILES.length} file</span>
            </div>

            {ANDROID_SOURCE_FILES.map((file) => {
              const isSelected = selectedFile.path === file.path;
              return (
                <button
                  key={file.path}
                  onClick={() => setSelectedFile(file)}
                  className={`w-full text-left p-2.5 rounded-xl transition-all flex flex-col space-y-1 ${
                    isSelected
                      ? 'bg-cyan-950/70 border border-cyan-800/80 text-white'
                      : 'hover:bg-slate-900 border border-transparent text-slate-400 hover:text-slate-200'
                  }`}
                >
                  <div className="flex items-center space-x-2">
                    <FileCode className={`w-4 h-4 shrink-0 ${isSelected ? 'text-cyan-400' : 'text-slate-500'}`} />
                    <span className="font-mono text-xs font-semibold truncate">{file.name}</span>
                  </div>
                  <span className="text-[10px] text-slate-500 truncate pl-6">{file.path}</span>
                </button>
              );
            })}

            {/* Quick Build Terminal Cheat Sheet */}
            <div className="mt-auto pt-4 border-t border-slate-800/80 px-2 space-y-2">
              <div className="flex items-center space-x-1.5 text-[11px] font-bold text-slate-300">
                <Terminal className="w-3.5 h-3.5 text-cyan-400" />
                <span>Perintah Build APK:</span>
              </div>
              <div className="bg-slate-950 p-2 rounded-lg border border-slate-800 font-mono text-[10px] text-cyan-300 select-all">
                ./gradlew assembleRelease
              </div>
            </div>
          </div>

          {/* Code Viewer (Right 8 cols) */}
          <div className="md:col-span-8 flex flex-col bg-slate-950 overflow-hidden">
            {/* Code Header Bar */}
            <div className="flex items-center justify-between px-4 py-2.5 border-b border-slate-800 bg-slate-900/60 shrink-0">
              <div className="flex items-center space-x-2 truncate">
                <span className="font-mono text-xs font-semibold text-cyan-400 truncate">
                  {selectedFile.path}
                </span>
                <span className="text-[10px] text-slate-500 uppercase px-1.5 py-0.5 rounded bg-slate-800 font-mono">
                  {selectedFile.language}
                </span>
              </div>

              <button
                onClick={handleCopyCode}
                className="flex items-center space-x-1.5 px-3 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-medium border border-slate-700 transition-colors"
              >
                {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copied ? 'Tersalin!' : 'Salin Kode'}</span>
              </button>
            </div>

            {/* Description Sub-bar */}
            <div className="px-4 py-1.5 bg-slate-900/30 border-b border-slate-800/60 text-[11px] text-slate-400 italic">
              {selectedFile.description}
            </div>

            {/* Raw Code Content */}
            <div className="flex-1 overflow-auto p-4 bg-slate-950">
              <pre className="font-mono text-xs leading-relaxed text-slate-200 select-all whitespace-pre">
                {selectedFile.content}
              </pre>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
