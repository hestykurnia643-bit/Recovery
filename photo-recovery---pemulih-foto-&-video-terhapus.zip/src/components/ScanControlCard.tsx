import React, { useRef } from 'react';
import { Play, RotateCw, XCircle, FolderSearch, HardDrive, CheckCircle2, AlertTriangle, ShieldCheck } from 'lucide-react';
import { ScanStats } from '../types';

interface ScanControlCardProps {
  stats: ScanStats;
  isScanning: boolean;
  onStartDeepScan: () => void;
  onCancelScan: () => void;
  onResetScan: () => void;
  onSelectLocalFolder: (files: FileList) => void;
  hasResults: boolean;
}

export const ScanControlCard: React.FC<ScanControlCardProps> = ({
  stats,
  isScanning,
  onStartDeepScan,
  onCancelScan,
  onResetScan,
  onSelectLocalFolder,
  hasResults
}) => {
  const fileInputRef = useRef<HTMLInputElement>(null);

  const formatBytes = (bytes: number) => {
    if (bytes === 0) return '0 B';
    const k = 1024;
    const sizes = ['B', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(1)) + ' ' + sizes[i];
  };

  const handleFolderClick = () => {
    fileInputRef.current?.click();
  };

  const handleFolderChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      onSelectLocalFolder(e.target.files);
    }
  };

  return (
    <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-4 sm:p-6 shadow-xl relative overflow-hidden backdrop-blur-sm">
      {/* Background glowing ambient light */}
      <div className="absolute -top-24 -right-24 w-64 h-64 bg-cyan-500/10 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute -bottom-24 -left-24 w-64 h-64 bg-teal-500/10 rounded-full blur-3xl pointer-events-none" />

      {/* Hidden Folder Input for Physical Folder / SD Card / MTP Scan */}
      <input
        type="file"
        ref={fileInputRef}
        onChange={handleFolderChange}
        // @ts-expect-error webkitdirectory is standard in Chromium browsers
        webkitdirectory=""
        directory=""
        multiple
        className="hidden"
      />

      <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-6">
        {/* Left Column: Title & Mission Description */}
        <div className="space-y-2 max-w-2xl">
          <div className="inline-flex items-center space-x-2 px-2.5 py-1 rounded-full bg-cyan-950/80 border border-cyan-800/50 text-cyan-300 text-xs font-semibold">
            <span className="w-2 h-2 rounded-full bg-cyan-400 animate-ping" />
            <span>Algoritma Non-Root: .thumbdata Carving & Trash Residual</span>
          </div>

          <h2 className="text-xl sm:text-2xl font-extrabold text-white tracking-tight">
            Pemulihan Foto & Video Terhapus dari Trash HP
          </h2>

          <p className="text-sm text-slate-300 leading-relaxed">
            Memindai jejak mendalam dari tong sampah sistem, database thumbnail biner (<code className="text-cyan-300 bg-slate-950 px-1 py-0.5 rounded text-xs">DCIM/.thumbnails/.thumbdata4</code>), cache media aplikasi terhapus, dan fragmen terisolir.
            <span className="text-amber-300 font-medium block mt-1">
              *Foto dan video yang masih aktif normal di Galeri otomatis difilter & dikecualikan.
            </span>
          </p>
        </div>

        {/* Right Column: Main Action Buttons */}
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3 shrink-0">
          {!isScanning ? (
            <>
              <button
                onClick={onStartDeepScan}
                className="group relative inline-flex items-center justify-center space-x-2.5 px-6 py-3.5 rounded-xl bg-gradient-to-r from-cyan-500 to-teal-500 text-slate-950 font-bold shadow-lg shadow-cyan-500/25 hover:shadow-cyan-500/40 hover:from-cyan-400 hover:to-teal-400 active:scale-[0.98] transition-all cursor-pointer text-sm"
              >
                <Play className="w-4 h-4 fill-current transition-transform group-hover:scale-110" />
                <span>Mulai Deep Scan</span>
              </button>

              <button
                onClick={handleFolderClick}
                className="inline-flex items-center justify-center space-x-2 px-4 py-3.5 rounded-xl bg-slate-800 hover:bg-slate-700/80 border border-slate-700 hover:border-slate-600 text-slate-200 font-semibold text-sm transition-all"
                title="Pilih folder cadangan, SD Card, atau mount DCIM smartphone fisik"
              >
                <FolderSearch className="w-4 h-4 text-cyan-400" />
                <span>Pilih Folder / SD Card</span>
              </button>

              {hasResults && (
                <button
                  onClick={onResetScan}
                  className="inline-flex items-center justify-center space-x-2 px-3 py-3.5 rounded-xl bg-slate-800/80 hover:bg-slate-700 border border-slate-700 text-slate-300 text-sm font-medium transition-all"
                  title="Scan Ulang dari awal"
                >
                  <RotateCw className="w-4 h-4 text-slate-400" />
                  <span className="hidden sm:inline">Scan Ulang</span>
                </button>
              )}
            </>
          ) : (
            <div className="flex items-center gap-3">
              <button
                onClick={onCancelScan}
                className="inline-flex items-center justify-center space-x-2 px-5 py-3 rounded-xl bg-rose-950/80 hover:bg-rose-900 border border-rose-800 text-rose-300 font-semibold text-sm transition-all cursor-pointer"
              >
                <XCircle className="w-4 h-4 text-rose-400" />
                <span>Batalkan Scan</span>
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Scanning Progress Bar & Live Status */}
      {isScanning && (
        <div className="mt-6 pt-5 border-t border-slate-800 space-y-3">
          <div className="flex items-center justify-between text-xs">
            <span className="font-semibold text-cyan-400 flex items-center space-x-1.5">
              <HardDrive className="w-3.5 h-3.5 animate-spin" />
              <span>
                {stats.phase === 'querying_mediastore' && 'Memeriksa MediaStore Android...'}
                {stats.phase === 'filtering_active_gallery' && 'Memfilter & Mengecualikan Galeri Aktif...'}
                {stats.phase === 'scanning_thumbnail_db' && 'Membedah Database Thumbnail DCIM/.thumbnails...'}
                {stats.phase === 'carving_raw_thumbdata' && 'Carving Magic Byte SOI 0xFFD8 di .thumbdata...'}
                {stats.phase === 'scanning_trash_residuals' && 'Memindai Jejak Sampah & Cache Aplikasi...'}
                {stats.phase === 'carving_lost_dir_fragments' && 'Memeriksa Cluster LOST.DIR & Unlinked Inodes...'}
                {stats.phase === 'verifying_headers' && 'Memvalidasi Integritas File & Header...'}
                {stats.phase === 'completed' && 'Pemeriksaan Selesai!'}
              </span>
            </span>
            <span className="text-slate-400 font-mono font-medium">
              {Math.round(stats.progressPercent)}%
            </span>
          </div>

          {/* Progress Bar with glowing stripe */}
          <div className="w-full h-2.5 bg-slate-950 rounded-full overflow-hidden p-0.5 border border-slate-800">
            <div
              className="h-full bg-gradient-to-r from-cyan-500 via-teal-400 to-emerald-400 rounded-full transition-all duration-300 relative overflow-hidden"
              style={{ width: `${stats.progressPercent}%` }}
            >
              <div className="absolute inset-0 bg-white/20 animate-pulse" />
            </div>
          </div>

          {/* Current Path Indicator */}
          <div className="flex items-center justify-between text-[11px] text-slate-400 font-mono truncate">
            <span className="truncate max-w-[80%]">
              Path: <span className="text-slate-300">{stats.currentPath}</span>
            </span>
            <span className="shrink-0 text-slate-500">
              Waktu: {stats.elapsedSeconds}s
            </span>
          </div>
        </div>
      )}

      {/* Live Stats Counters Bar - 6 Explicit Forensic Tiers */}
      <div className="mt-5 grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2.5 pt-4 border-t border-slate-800/80">
        <div className="bg-slate-950/70 p-2.5 rounded-xl border border-emerald-900/60">
          <div className="text-[10px] text-emerald-400 font-bold flex items-center space-x-1">
            <span className="w-2 h-2 rounded-full bg-emerald-400" />
            <span>FULL_VALID (Asli)</span>
          </div>
          <div className="text-base font-bold text-white mt-0.5">
            {stats.fullValidCount} <span className="text-[10px] font-normal text-slate-400">media</span>
          </div>
        </div>

        <div className="bg-slate-950/70 p-2.5 rounded-xl border border-amber-900/60">
          <div className="text-[10px] text-amber-400 font-bold flex items-center space-x-1">
            <span className="w-2 h-2 rounded-full bg-amber-400" />
            <span>PARTIAL</span>
          </div>
          <div className="text-base font-bold text-white mt-0.5">
            {stats.partialCount} <span className="text-[10px] font-normal text-slate-400">fragment</span>
          </div>
        </div>

        <div className="bg-slate-950/70 p-2.5 rounded-xl border border-orange-900/60">
          <div className="text-[10px] text-orange-400 font-bold flex items-center space-x-1">
            <span className="w-2 h-2 rounded-full bg-orange-400" />
            <span>HEADER ONLY</span>
          </div>
          <div className="text-base font-bold text-orange-300 mt-0.5">
            {stats.headerCorruptCount} <span className="text-[10px] font-normal text-slate-500">korup</span>
          </div>
        </div>

        <div className="bg-slate-950/70 p-2.5 rounded-xl border border-blue-900/60">
          <div className="text-[10px] text-blue-400 font-bold flex items-center space-x-1">
            <span className="w-2 h-2 rounded-full bg-blue-400" />
            <span>THUMB ONLY</span>
          </div>
          <div className="text-base font-bold text-white mt-0.5">
            {stats.thumbnailOnlyCount} <span className="text-[10px] font-normal text-slate-400">cache</span>
          </div>
        </div>

        <div className="bg-slate-950/70 p-2.5 rounded-xl border border-slate-800">
          <div className="text-[10px] text-slate-400 font-bold flex items-center space-x-1">
            <span className="w-2 h-2 rounded-full bg-slate-500" />
            <span>METADATA ONLY</span>
          </div>
          <div className="text-base font-bold text-slate-300 mt-0.5">
            {stats.metadataOnlyCount} <span className="text-[10px] font-normal text-slate-500">record</span>
          </div>
        </div>

        <div className="bg-slate-950/70 p-2.5 rounded-xl border border-slate-800">
          <div className="text-[10px] text-slate-400 font-bold flex items-center space-x-1">
            <ShieldCheck className="w-3 h-3 text-emerald-400" />
            <span>Galeri Aktif</span>
          </div>
          <div className="text-base font-bold text-slate-300 mt-0.5">
            {stats.activeGallerySkipped} <span className="text-[10px] font-normal text-slate-500">dilewati</span>
          </div>
        </div>
      </div>
    </div>
  );
};
