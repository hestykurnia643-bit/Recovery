import React from 'react';
import { Download, CheckSquare, X } from 'lucide-react';
import { RecoveredMediaItem } from '../types';

interface BottomActionBarProps {
  selectedItems: RecoveredMediaItem[];
  onOpenRecoveryModal: () => void;
  onClearSelection: () => void;
}

export const BottomActionBar: React.FC<BottomActionBarProps> = ({
  selectedItems,
  onOpenRecoveryModal,
  onClearSelection
}) => {
  if (selectedItems.length === 0) return null;

  const totalBytes = selectedItems.reduce((acc, item) => acc + item.sizeBytes, 0);

  const formatBytes = (bytes: number) => {
    if (bytes === 0) return '0 B';
    const k = 1024;
    const sizes = ['B', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(1)) + ' ' + sizes[i];
  };

  return (
    <div className="fixed bottom-4 left-4 right-4 z-40 max-w-2xl mx-auto animate-in slide-in-from-bottom-5 duration-200">
      <div className="bg-slate-900/95 backdrop-blur-md border border-cyan-500/40 rounded-2xl p-3 sm:p-4 shadow-2xl shadow-cyan-950/60 flex items-center justify-between gap-3">
        {/* Selection Count Info */}
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 rounded-xl bg-cyan-500/10 border border-cyan-500/30 flex items-center justify-center text-cyan-400">
            <CheckSquare className="w-5 h-5" />
          </div>
          <div>
            <div className="text-sm font-bold text-white flex items-center space-x-1.5">
              <span>{selectedItems.length} file dipilih</span>
              <span className="text-slate-500">•</span>
              <span className="text-cyan-400 font-mono text-xs">{formatBytes(totalBytes)}</span>
            </div>
            <p className="text-[11px] text-slate-400">
              Siap dipulihkan ke <span className="text-slate-300 font-mono">/Pictures/Recovered_Media</span>
            </p>
          </div>
        </div>

        {/* Buttons */}
        <div className="flex items-center space-x-2">
          <button
            onClick={onClearSelection}
            className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
            title="Batal pilih"
          >
            <X className="w-4 h-4" />
          </button>

          <button
            onClick={onOpenRecoveryModal}
            className="px-4 sm:px-5 py-2.5 rounded-xl bg-gradient-to-r from-cyan-500 to-teal-500 hover:from-cyan-400 hover:to-teal-400 text-slate-950 font-bold text-xs sm:text-sm flex items-center space-x-2 shadow-lg shadow-cyan-500/25 active:scale-[0.98] transition-all cursor-pointer whitespace-nowrap"
          >
            <Download className="w-4 h-4 stroke-[2.5]" />
            <span>Pulihkan ({selectedItems.length}) File</span>
          </button>
        </div>
      </div>
    </div>
  );
};
