import React, { useState } from 'react';
import { X, CheckCircle2, ShieldAlert, Folder, Download, HardDrive, Check, PackageCheck } from 'lucide-react';
import JSZip from 'jszip';
import { RecoveredMediaItem } from '../types';

interface RecoveryConfirmationModalProps {
  items: RecoveredMediaItem[];
  isOpen: boolean;
  onClose: () => void;
  onConfirmRecovery: () => void;
}

export const RecoveryConfirmationModal: React.FC<RecoveryConfirmationModalProps> = ({
  items,
  isOpen,
  onClose,
  onConfirmRecovery
}) => {
  const [targetPath, setTargetPath] = useState('/storage/emulated/0/Pictures/Recovered_Media/');
  const [isRestoring, setIsRestoring] = useState(false);
  const [success, setSuccess] = useState(false);

  if (!isOpen || items.length === 0) return null;

  const totalBytes = items.reduce((acc, item) => acc + item.sizeBytes, 0);

  const formatBytes = (bytes: number) => {
    if (bytes === 0) return '0 B';
    const k = 1024;
    const sizes = ['B', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(1)) + ' ' + sizes[i];
  };

  const handleStartRecovery = async () => {
    setIsRestoring(true);
    try {
      if (items.length === 1 && items[0].blob) {
        // Unduh single file langsung
        const item = items[0];
        const blobToDownload = item.blob;
        if (blobToDownload) {
          const a = document.createElement('a');
          a.href = URL.createObjectURL(blobToDownload);
          a.download = `Restored_${item.name}`;
          document.body.appendChild(a);
          a.click();
          document.body.removeChild(a);
          URL.revokeObjectURL(a.href);
        }
      } else {
        // Kemas dalam folder Recovered_Media via ZIP
        const zip = new JSZip();
        const folder = zip.folder('Pictures/Recovered_Media');

        for (const item of items) {
          if (item.blob) {
            folder?.file(item.name, item.blob);
          } else {
            // Jika blob tidak ada, fetch dari previewUrl
            try {
              const resp = await fetch(item.previewUrl);
              const blob = await resp.blob();
              folder?.file(item.name, blob);
            } catch (err) {
              console.warn('Gagal menambahkan ke zip:', item.name, err);
            }
          }
        }

        const zipBlob = await zip.generateAsync({ type: 'blob' });
        const url = URL.createObjectURL(zipBlob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `Recovered_Media_${new Date().toISOString().slice(0, 10)}.zip`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
      }

      setIsRestoring(false);
      setSuccess(true);
      setTimeout(() => {
        onConfirmRecovery();
        setSuccess(false);
        onClose();
      }, 1200);
    } catch (err) {
      console.error('Error saat pemulihan:', err);
      setIsRestoring(false);
      onConfirmRecovery();
      onClose();
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md animate-in fade-in duration-200">
      <div className="relative w-full max-w-lg bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between p-5 border-b border-slate-800 bg-slate-900/90">
          <div className="flex items-center space-x-2.5">
            <div className="p-2 rounded-xl bg-cyan-950/80 border border-cyan-800/60 text-cyan-400">
              <Download className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-white">Konfirmasi Pemulihan Media</h3>
              <p className="text-xs text-slate-400">Persetujuan pengguna sebelum penulisan penyimpanan</p>
            </div>
          </div>
          <button
            onClick={onClose}
            disabled={isRestoring}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-5 space-y-4">
          {/* Target Location Box */}
          <div className="bg-slate-950 p-3.5 rounded-xl border border-slate-800 space-y-2">
            <div className="flex items-center space-x-2 text-xs font-semibold text-slate-300">
              <Folder className="w-4 h-4 text-cyan-400" />
              <span>Folder Tujuan Pemulihan (Scoped Storage)</span>
            </div>
            <div className="p-2 bg-slate-900 rounded-lg border border-slate-800 font-mono text-xs text-cyan-300 break-all select-all">
              {targetPath}
            </div>
            <p className="text-[11px] text-slate-400 leading-normal">
              File asli di media cluster tidak akan tertimpa. Salinan bersih akan ditulis ke direktori resmi media storage agar langsung terbaca di Galeri HP.
            </p>
          </div>

          {/* Selected Summary */}
          <div className="p-3 bg-slate-950/60 rounded-xl border border-slate-800 flex items-center justify-between text-xs">
            <div>
              <span className="text-slate-400">Jumlah File Terpilih:</span>{' '}
              <span className="font-bold text-white">{items.length} media</span>
            </div>
            <div>
              <span className="text-slate-400">Total Ukuran:</span>{' '}
              <span className="font-bold text-cyan-400 font-mono">{formatBytes(totalBytes)}</span>
            </div>
          </div>

          {/* Items Preview List (Scrollable) */}
          <div className="max-h-40 overflow-y-auto space-y-1.5 pr-1">
            {items.map((item) => (
              <div
                key={item.id}
                className="flex items-center justify-between p-2 rounded-lg bg-slate-950/40 border border-slate-800/60 text-xs"
              >
                <div className="flex items-center space-x-2 truncate">
                  <span className="px-1.5 py-0.5 rounded text-[10px] font-mono font-bold bg-slate-800 text-cyan-300">
                    {item.format}
                  </span>
                  <span className="text-slate-200 truncate max-w-[200px]" title={item.name}>
                    {item.name}
                  </span>
                </div>
                <span className="text-slate-400 font-mono text-[11px] shrink-0">
                  {item.formattedSize}
                </span>
              </div>
            ))}
          </div>

          {/* Safety Notice */}
          <div className="flex items-start space-x-2 p-3 rounded-xl bg-cyan-950/30 border border-cyan-800/40 text-xs text-slate-300">
            <ShieldAlert className="w-4 h-4 text-cyan-400 shrink-0 mt-0.5" />
            <span>
              Sistem akan memvalidasi header file secara langsung sebelum menyimpan data untuk mencegah file korup merusak cache galeri Anda.
            </span>
          </div>
        </div>

        {/* Footer Actions */}
        <div className="p-4 border-t border-slate-800 bg-slate-900/90 flex items-center justify-end space-x-3">
          <button
            onClick={onClose}
            disabled={isRestoring}
            className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold transition-colors"
          >
            Batal
          </button>

          <button
            onClick={handleStartRecovery}
            disabled={isRestoring || success}
            className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-cyan-500 to-teal-500 hover:from-cyan-400 hover:to-teal-400 text-slate-950 font-bold text-xs flex items-center space-x-2 shadow-lg shadow-cyan-500/25 active:scale-[0.98] transition-all"
          >
            {isRestoring ? (
              <>
                <HardDrive className="w-4 h-4 animate-spin text-slate-950" />
                <span>Menulis ke MediaStore...</span>
              </>
            ) : success ? (
              <>
                <Check className="w-4 h-4 stroke-[3]" />
                <span>Berhasil Dipulihkan!</span>
              </>
            ) : (
              <>
                <Download className="w-4 h-4" />
                <span>Setujui & Pulihkan ({items.length}) File</span>
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
};
