import React from 'react';
import { Search, CheckSquare, Square, Filter, Image, Film } from 'lucide-react';
import { RecoveryTier } from '../types';

interface MediaFilterBarProps {
  selectedType: 'all' | 'image' | 'video';
  onSelectType: (type: 'all' | 'image' | 'video') => void;
  selectedTier: string;
  onSelectTier: (tier: string) => void;
  searchQuery: string;
  onSearchChange: (query: string) => void;
  allSelected: boolean;
  someSelected: boolean;
  onToggleSelectAll: () => void;
  totalFilteredCount: number;
  totalSelectedCount: number;
}

export const MediaFilterBar: React.FC<MediaFilterBarProps> = ({
  selectedType,
  onSelectType,
  selectedTier,
  onSelectTier,
  searchQuery,
  onSearchChange,
  allSelected,
  someSelected,
  onToggleSelectAll,
  totalFilteredCount,
  totalSelectedCount
}) => {
  return (
    <div className="bg-slate-900/60 border border-slate-800 rounded-xl p-3 sm:p-4 space-y-3">
      {/* Top Row: Type Pills & Select All Button */}
      <div className="flex flex-wrap items-center justify-between gap-3">
        {/* Type Filter Buttons */}
        <div className="flex items-center space-x-1.5 bg-slate-950/80 p-1 rounded-lg border border-slate-800/80 text-xs">
          <button
            onClick={() => onSelectType('all')}
            className={`px-3 py-1.5 rounded-md font-medium transition-all ${
              selectedType === 'all'
                ? 'bg-cyan-500 text-slate-950 font-semibold shadow-sm'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            Semua Format
          </button>
          <button
            onClick={() => onSelectType('image')}
            className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-md font-medium transition-all ${
              selectedType === 'image'
                ? 'bg-cyan-500 text-slate-950 font-semibold shadow-sm'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Image className="w-3.5 h-3.5" />
            <span>Foto (JPG/PNG/WEBP/HEIC)</span>
          </button>
          <button
            onClick={() => onSelectType('video')}
            className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-md font-medium transition-all ${
              selectedType === 'video'
                ? 'bg-cyan-500 text-slate-950 font-semibold shadow-sm'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Film className="w-3.5 h-3.5" />
            <span>Video (MP4/MOV)</span>
          </button>
        </div>

        {/* Select All Checkbox Button */}
        <button
          onClick={onToggleSelectAll}
          className={`flex items-center space-x-2 px-3 py-1.5 rounded-lg border text-xs font-semibold transition-all ${
            allSelected
              ? 'bg-cyan-950/60 border-cyan-500 text-cyan-300'
              : someSelected
              ? 'bg-slate-800 border-slate-600 text-slate-200'
              : 'bg-slate-800/60 border-slate-700 text-slate-400 hover:text-slate-200'
          }`}
        >
          {allSelected ? (
            <CheckSquare className="w-4 h-4 text-cyan-400" />
          ) : (
            <Square className="w-4 h-4 text-slate-500" />
          )}
          <span>
            {allSelected
              ? 'Batal Pilih Semua'
              : totalSelectedCount > 0
              ? `${totalSelectedCount} Dipilih (Pilih Semua)`
              : 'Pilih Semua Valid'}
          </span>
        </button>
      </div>

      {/* Bottom Row: Search & Tier Filter */}
      <div className="flex flex-col sm:flex-row items-center gap-3">
        {/* Search Input */}
        <div className="relative flex-1 w-full">
          <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none" />
          <input
            type="text"
            placeholder="Cari berdasarkan nama, format, atau cluster..."
            value={searchQuery}
            onChange={(e) => onSearchChange(e.target.value)}
            className="w-full bg-slate-950 border border-slate-800 rounded-lg pl-9 pr-4 py-2 text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-cyan-500 transition-colors"
          />
          {searchQuery && (
            <button
              onClick={() => onSearchChange('')}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-200 text-xs"
            >
              ✕
            </button>
          )}
        </div>

        {/* Tier Classification Filter Selector */}
        <div className="flex items-center space-x-2 w-full sm:w-auto shrink-0">
          <Filter className="w-3.5 h-3.5 text-slate-400 shrink-0" />
          <select
            value={selectedTier}
            onChange={(e) => onSelectTier(e.target.value)}
            className="bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-slate-300 focus:outline-none focus:border-cyan-500 cursor-pointer w-full sm:w-auto"
          >
            <option value="all">Semua Kategori Forensik</option>
            <option value="FULL_VALID">🟢 FULL_VALID: Terdekode & Asli</option>
            <option value="PARTIAL">🟡 PARTIAL: Fragment / Sebagian</option>
            <option value="HEADER_ONLY/CORRUPT">🟠 HEADER_ONLY: Gagal Decode</option>
            <option value="THUMBNAIL_ONLY">🔵 THUMBNAIL ONLY: Cache Sistem</option>
            <option value="METADATA_ONLY">⚪ METADATA ONLY: Sektor Fisik Kosong</option>
            <option value="UNRECOVERABLE">🔴 UNRECOVERABLE: Rusak Total</option>
          </select>
        </div>

        {/* Total Filtered Count */}
        <div className="text-xs text-slate-400 shrink-0 whitespace-nowrap self-end sm:self-center">
          Menampilkan: <span className="font-semibold text-white">{totalFilteredCount}</span> item
        </div>
      </div>
    </div>
  );
};
